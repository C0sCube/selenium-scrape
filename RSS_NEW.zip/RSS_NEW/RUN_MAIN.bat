@echo off

echo ==========================================
echo Starting Adverse News Parallel Scheduler
echo ==========================================

REM ---- Activate Virtual Environment ----
call .venv\Scripts\activate

REM ---- Change Directory to Project Root ----
cd /d "%~dp0"

REM ---- Run Main Parallel Scheduler ----
python mainv1.py

pause