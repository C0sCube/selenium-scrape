import threading
from datetime import datetime
import os
import traceback

from app.constants import get_log_dir
from app.logger import setup_logger
from app.news import AdverseNewsDetetor
from app.utils import Helper
from app.mailer import Mailer


PROG_NAME = "Adverse News Aggregator (GOOGLE/BING)"

def safe_execute(name, fn):
    """
    Runs a function safely in its own thread.
    Prevents scheduler from getting stuck.
    """
    def wrapper():
        logger.info(f"[{name}] STARTED @ {datetime.now().strftime('%H:%M:%S')}")
        try:
            fn()
            logger.info(f"[{name}] COMPLETED")
        except Exception as e:
            logger.error(f"[{name}] FAILED: {type(e).__name__}: {e}")
            logger.error(traceback.format_exc())

    t = threading.Thread(target=wrapper, daemon=True)
    t.start()

# interval runner
def fetch_runner():
    def job():
        handler = AdverseNewsDetetor()
        handler.rss_handler(mode="single", ts="3h")

    safe_execute("FETCH", job)

# 24h runner
def aggregate_runner():
    def job():
        handler = AdverseNewsDetetor()
        mailer = Mailer()

        output_dir = handler.program_24h_handler()

        logger.info("Zipping output directory...")
        timestamp = datetime.now().strftime("%Y%m%d")

        zip_path = os.path.abspath(
            os.path.join(output_dir, "..", f"ADVERSE_NEWS_{timestamp}.zip")
        )

        helper.zip_folder(output_dir, zip_path)
        
        if mailer.SEND_MAIL:
            mailer.end_mail(
                PROG_NAME,
                attachments= zip_path
            )

        logger.info("Pipeline completed successfully.")

        # Optional cleanup
        try:
            os.rmdir(output_dir)
        except:
            pass

    safe_execute("AGGREGATE", job)



if __name__ == "__main__":

    log_dir = get_log_dir()
    logger = setup_logger("adv_log",log_dir=log_dir,use_color=True, make_global=True)
    helper = Helper()

    logger.info("=" * 60)
    logger.info("STARTING PARALLEL SCHEDULER SYSTEM")

    days = ["mon","tue","wed","thu","fri","sat","sun"]
    fetch_times = ["0014", "0017", "0023", "0028", "0032"]
    agg_times   = ["0020"]

    # --- Scheduler Threads ---
    fetch_scheduler = threading.Thread(
        target=helper.scheduler_loop,
        args=(logger, fetch_runner, days, fetch_times),
        daemon=False   # 🔥 important change
    )

    agg_scheduler = threading.Thread(
        target=helper.scheduler_loop,
        args=(logger, aggregate_runner, days, agg_times),
        daemon=False   # 🔥 important change
    )

    fetch_scheduler.start()
    agg_scheduler.start()

    # --- Keep Main Alive Safely ---
    try:
        fetch_scheduler.join()
        agg_scheduler.join()
    except KeyboardInterrupt:
        logger.info("Shutdown signal received. Exiting gracefully...")