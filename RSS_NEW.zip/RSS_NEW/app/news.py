import os
import re
import time
import pytz
import hashlib
import feedparser #type:ignore
import pandas as pd
from datetime import datetime, timedelta, timezone
from html import unescape
from urllib.parse import quote_plus
from app.logger import get_global_logger, log_exceptions
from app.utils import Helper

from app.constants import *
from concurrent.futures import ThreadPoolExecutor


IST = pytz.timezone('Asia/Kolkata')


class AdverseNewsDetetor:
    
    def __init__(self):
        
        self.HELPER = Helper()

        self.log = get_global_logger()
        self.CONFIG = config_program
        self.ADV_KW_CONFIG = get_adverse_kw_config
    
        self.OUTPUT_RAW_DIR = get_raw_dir()
        self.OUTPUT_DIR = get_output_dir()
        self.RSS_RUN_PATH = "rss_{_time}.json"
    
        self.RSS_DELAY = 0.2

        #buckets
        self.RSS_ENGINES = None
        self.EVENT_BUCKETS = self.ADV_KW_CONFIG()
        self.COMPANY_BUCKETS = None

        # paths
        self.EVENT_REGEX_PATTERN = None
        self.COMPANY_REGEX_PATTERN = None
        self.ALIAS_LOOKUP = None
        

    def detect_events(self, text: str) -> list:
        return list(set(self.EVENT_REGEX_PATTERN.findall(text)))

    def detect_companies(self, text: str) -> list:
        return list(set(self.COMPANY_REGEX_PATTERN.findall(text)))
   
    def _get_company_regex(self):
        alias_lookup = {}
        for company, aliases in self.COMPANY_BUCKETS.items():

            all_aliases = [company] + aliases
            for alias in all_aliases:
                alias = alias.lower()
                alias_lookup.setdefault(alias, []).append(company)

        aliases_sorted = sorted(alias_lookup.keys(), key=len, reverse=True)
        pattern = r"\b(" + "|".join(map(re.escape, aliases_sorted)) + r")\b"
        company_pattern = re.compile(pattern, re.IGNORECASE)
        return alias_lookup, company_pattern   

    def _get_event_regex(self):
       
        kwrds = [
            kw.lower() for buc in self.EVENT_BUCKETS.values()
            for kw in buc
        ]
        pattern = r"\b(" + "|".join(map(re.escape, kwrds)) + r")\b"
        return re.compile(pattern, re.IGNORECASE) 
    
    #-----------------RSS ENGINE--------------------
    
    @staticmethod
    def _set_time_for_rss_query(engines:dict,ts:str): 
        for key,details in engines.items():
            if "google" in key.lower():
                details.update({"time":ts})
        return engines
        
    def _generate_hash(self, entry):
        title = entry.get("title", "")
        link = entry.get("link", "")

        title = self._clean_title(title).lower()
        text = f"{title}|{link}"
        return hashlib.md5(text.encode()).hexdigest()
    
    def _clean_title(self, title: str) -> str:
        
        if not title:
            return ""
        title = re.sub(r"[^A-Za-z0-9\s\-\&\:\'\,\.\(\)]", "", title)
        title = re.sub(r"\s+", " ", title)
        return title.strip()
    
    def _fetch_engine(self, engine, details, keywords):

        rows = []
        for k in keywords:
            query = quote_plus(f'"{k}"')
            if "google" in engine:
                ts = details["time"]
                url = details["link"].format(query=query, ts=ts)
            else:
                url = details["link"].format(query=query)

            feed = feedparser.parse(url)
            total_entries = len(feed.entries)
            
            for entry in feed.entries:
                entry_dict = dict(entry)
                rows.append({
                    "fetched_at": datetime.now().strftime("%Y%m%d_%H%M"),
                    "hash": self._generate_hash(entry_dict),
                    "engine": engine,
                    "keyword": k,
                    "rss_entry": entry_dict
                })

            time.sleep(self.RSS_DELAY)
            self.log.info(f"{engine}: {k} fetched {total_entries} row(s)")

        return rows

    def rss_aggregator(self):
        
        rows = []
        keywords = [ kw for bucket in self.EVENT_BUCKETS.values() for kw in bucket][:5]
        with ThreadPoolExecutor(max_workers=len(self.RSS_ENGINES)) as executor:

            futures = [
                executor.submit(self._fetch_engine, engine, details, keywords)
                for engine, details in self.RSS_ENGINES.items()
            ]
            for f in futures: rows.extend(f.result())
    
        return rows
    
    #----------------- POST PROCESSING --------------------
                   
    def _clean_24_dataset(self,df: pd.DataFrame) -> pd.DataFrame:

        TAG_RE = re.compile(r"<.*?>")
        df["summary"] = df["summary"].apply( lambda x: re.sub(r"\s+", " ", TAG_RE.sub("", unescape(str(x)))).strip())
        df["summary"] = (df["summary"].fillna("").str.replace(r"[^\x20-\x7E]", "", regex=True).str.replace(r"\s+", " ", regex=True).str.strip())
        df["title"] = (df["title"].fillna("").str.replace(r"[^\x20-\x7E]", "", regex=True).str.replace(r"\s+", " ", regex=True).str.strip())
        df["published"] = pd.to_datetime(df["published"], errors="coerce")
        return df
        
    def _build_records_from_entries(self, unique_entries):
        records = []

        for r in unique_entries:
            engine, entry = r["engine"], r["rss_entry"]
            title, link, published, summary = (
                entry.get("title"),
                entry.get("link"),
                entry.get("published"),
                entry.get("summary")
            )
            
            source = ""
            if "google" in engine:
                source = entry.get("source", {}).get("title","")
                title = self.HELPER.apply_sub(title, source, "", ignore_case=True)
                summary = self.HELPER.apply_sub(summary, source, "", ignore_case=True)

            elif engine == "bing":
                source = entry.get("news_source","")
            
            records.append({
                "published": published,
                "engine": engine,
                "keyword":r["keyword"],
                "title": title,
                "summary": summary,
                "source": source,
                "link": link
            })

        df = pd.DataFrame(records)
        return self._clean_24_dataset(df)
    
    def build_data(self, path: str) -> pd.DataFrame:
        snapshot_json = self.HELPER.load_json(path)

        seen_hash = set()
        unique_entries = []

        for entry in snapshot_json:
            h = entry["hash"]
            if h not in seen_hash:
                seen_hash.add(h)
                unique_entries.append(entry)
                
                
        df1 =  self._build_records_from_entries(unique_entries)          
        if df1.empty:
            self.log.warning("No news found in last 24h")
            return
        
        return df1

    def build_24h_data(self, dir: str) -> pd.DataFrame:
        file_pattern = re.compile(r"rss_(\d{8})_(\d{4})\.json")
        cutoff = datetime.now() - timedelta(hours=24)

        files = []
        for f in os.listdir(dir):
            match = file_pattern.match(f)
            if not match:
                continue
            date_str, time_str = match.groups()
            file_dt = datetime.strptime(date_str + time_str, "%Y%m%d%H%M")
            if file_dt >= cutoff:
                files.append(os.path.join(dir, f))

        seen_hash = set()
        unique_entries = []

        for fp in files:
            self.log.info(f"file matched: {fp}")
            snapshot_json = self.HELPER.load_json(fp)
            for entry in snapshot_json:
                h = entry["hash"]
                if h not in seen_hash:
                    seen_hash.add(h)
                    unique_entries.append(entry)
        self.log.info(f"Total Unique Entries: {len(unique_entries)}")
        df1 =  self._build_records_from_entries(unique_entries)          
        # if df1.empty:
        #     self.log.warning("No news found in last 24h")
        #     return

        return df1

    def procs_data(self, df: pd.DataFrame, keep_matched_only = True) -> pd.DataFrame:

        if df.empty:
            return df

        config = self.CONFIG()
        self.COMPANY_BUCKETS = config["companies"]

        self.EVENT_REGEX_PATTERN = self._get_event_regex()
        self.ALIAS_LOOKUP, self.COMPANY_REGEX_PATTERN = self._get_company_regex()

        # -------- clean summary --------
        TAG_RE = re.compile(r"<.*?>")

        df["summary"] = df["summary"].apply(lambda x: re.sub(r"\s+", " ", TAG_RE.sub("", unescape(str(x)))).strip())
        df["text"] = (df["title"].fillna("") + " " + df["summary"].fillna("")).str.strip()

        df["companies"] = df["text"].apply(self.detect_companies)
        df["keywords"] = df["text"].apply(self.detect_events)

        # convert lists → readable strings
        df["companies"] = df["companies"].apply(lambda x: "; ".join(x) if isinstance(x, list) and x else "")
        df["keywords"] = df["keywords"].apply(lambda x: "; ".join(x) if isinstance(x, list) and x else "")
        df["company_match"] = df["companies"].apply(lambda x: x.split(";")[0] if isinstance(x, str) and x else "")
        df["keyword_match"] = df["keywords"].apply(lambda x: x.split(";")[0] if isinstance(x, str) and x else "")

        # helper columns for sorting
        df["has_company"] = df["company_match"].str.len() > 0
        df["has_keyword"] = df["keyword_match"].str.len() > 0

        # sorting priority
        df = df.sort_values(
            by=["published","has_company", "has_keyword"],
            ascending=[False, False, False]
        )


        df = df.drop_duplicates(subset="link", keep="first")
        df = df.drop_duplicates(subset="title", keep="first")
        
        if keep_matched_only:
            df = df[df["company_match"] != ""]
            df = df[df["keyword_match"]!=""]
        
        df = df[["published","engine","keyword","keyword_match","company_match","source","title","summary","link"]]
        df = df.reset_index(drop=True)
        return df
    
    #----------------- HANDLERS --------------------

    @log_exceptions(level="error")  
    def rss_handler(self, mode:str, ts:str):
        """ Runs RSS engines and saves snapshot"""
        
        config = self.CONFIG()
        self.RSS_ENGINES = config["engines"]
        self.EVENT_BUCKETS = self.ADV_KW_CONFIG()
        
        if mode == "single":
            #reserved for one-time program run.
            self.RSS_ENGINES = AdverseNewsDetetor._set_time_for_rss_query(self.RSS_ENGINES,ts)
        
        rows = self.rss_aggregator()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M")
        final_path = os.path.join(self.OUTPUT_RAW_DIR, self.RSS_RUN_PATH.format(_time = timestamp))
        self.HELPER.save_json(rows,final_path)
        self.log.info(f"RSS snapshot saved: {final_path}")
        
        return final_path
    
    @log_exceptions(level="error")  
    def program_24h_handler(self):

        self.log.info("Starting 24H Adverse News Processing.")

        df = self.build_24h_data(self.OUTPUT_RAW_DIR)
        df1 = self.procs_data(df)        
        #dirs
        timestamp = datetime.now().strftime("%Y%m%d")
        dir = self.HELPER.create_dir(self.OUTPUT_DIR,f"NEWS_{timestamp}")
        raw_path = os.path.join(dir, f"RAW_{timestamp}.xlsx")
        final_path = os.path.join(dir, f"ADVERSE_NEWS_{timestamp}.xlsx")
        
        
        df.to_excel(raw_path, index=False)
        df1.to_excel(final_path, index=False)
        
        self.log.info("Aggregate News Saved.")
        return dir
   
    @log_exceptions(level="error")
    def prog_handler(self):
        """Handles Running of News Fetch @ Single Run Mode. Collects Raw File, Processes File
        
        parameters: None
        returns: directory (str)
        
        """
        
        self.log.info("Starting Single Run Processing.")
        self.log.info("Default to 24h OR configurable timestamp. Updating when:1d")
        
        json_path = self.rss_handler(mode = "single", ts="1d")
        df = self.build_data(json_path)
        df1 = self.procs_data(df)
        
        #dirs
        timestamp = datetime.now().strftime("%Y%m%d")
        dir = self.HELPER.create_dir(self.OUTPUT_DIR,f"NEWS_{timestamp}")
        raw_path = os.path.join(dir, f"RAW_{timestamp}.xlsx")
        final_path = os.path.join(dir, f"ADVERSE_NEWS_{timestamp}.xlsx")
        
        df.to_excel(raw_path, index=False)
        df1.to_excel(final_path, index=False)
        self.log.info("Aggregate News Saved.")
        
        return dir
