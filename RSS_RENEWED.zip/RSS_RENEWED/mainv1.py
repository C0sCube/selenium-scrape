import threading
from datetime import datetime
import os

from app.constants import get_log_dir, config_schedule
from app.logger import setup_logger, set_global_logger
from app.schedular import scheduler_loop
from app.news import AdverseNewsDetetor
from app.utils import Helper
from app.mailer import Mailer


PROG_NAME = "Adverse News Aggregator"


def fetch_runner():
    handler = AdverseNewsDetetor()
    handler.rss_handler(mode="single", ts="3h")


def aggregate_runner():
    handler = AdverseNewsDetetor()
    helper = Helper()
    mailer = Mailer()
    
    output_dir = handler.program_24h_handler()

    logger.info("Proceeding to Zip the DIR.")
    timestamp = datetime.now().strftime("%Y%m%d")

    zip_path = os.path.abspath(
        os.path.join(output_dir, "..", f"ADVERSE_NEWS_{timestamp}.zip")
    )

    helper.zip_folder(output_dir, zip_path)

    logger.info("Pipeline completed successfully.")
    os.remove(output_dir)


if __name__ == "__main__":

    log_dir = get_log_dir()
    logger = setup_logger("parallel_news_log", log_dir)
    set_global_logger(logger)

    sch_data = config_schedule()

    fetch_times = ["1640","1645","1650","1655","1753"]
    agg_times   = ["1812"]

    # -------- THREAD 1 → FETCH SCHEDULER --------
    fetch_scheduler = threading.Thread(
        target=scheduler_loop,
        args=(
            logger,
            fetch_runner,
            sch_data["days"],
            fetch_times
        ),
        daemon=True
    )

    agg_scheduler = threading.Thread(
        target=scheduler_loop,
        args=(
            logger,
            aggregate_runner,
            sch_data["days"],
            agg_times
        ),
        daemon=True
    )

    fetch_scheduler.start()
    agg_scheduler.start()

    fetch_scheduler.join()
    agg_scheduler.join()