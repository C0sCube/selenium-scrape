from datetime import datetime
import os

from app.constants import get_log_dir
from app.logger import setup_logger, set_global_logger
from app.news import AdverseNewsDetetor
from app.utils import Helper

PROG_NAME = "Adverse News Aggregator (SOLO – Manual Mode)"


def runner():
    logger.info("========== SOLO RUN STARTED ==========")
    
    try:
        handler = AdverseNewsDetetor()
        helper = Helper()
        # This runs your sliding window fetch logic
        # and stores snapshot (timestamped)
        output_dir = handler.prog_handler()
        
        logger.info("Proceding to Zip the DIR.")
        timestamp = datetime.now().strftime("%Y%m%d")
        zip_path = os.path.join(output_dir, "..",f"ADVERSE_NEWS_{timestamp}.zip")
        helper.zip_folder(output_dir,zip_path)
        logger.info(f"Pipeline completed successfully.")
        logger.info(f"Output Directory: {output_dir}")

    except Exception as e:
        logger.exception("SOLO RUN FAILED")

    logger.info("========== SOLO RUN COMPLETED ==========\n")


if __name__ == "__main__":

    log_dir = get_log_dir()
    logger = setup_logger("newslog", log_dir)
    set_global_logger(logger)

    logger.info(f"Starting SOLO Mode: {PROG_NAME}")
    logger.info(f"Run Time: {datetime.now().isoformat()}")
    runner()