from datetime import datetime

from app.logger import get_global_logger, log_exceptions
from app.engineSele import SeleniumEngine
from app.engineSoup import SoupEngine
from app.engineRSS import RssEngine #type: ignore

from app.utils import Helper
from app.constants import *

class BlockExecutor:
    
    def __init__(self,engine:str, all_contracts:list):
        
        #generic
        self.ENGINE = engine
        self.LOGGER = get_global_logger()
        self.GENERIC_ACTIONS = load_gen_config()
        self.HELPER = Helper()
        
        
        self.ENGINE_TYPE = {
            "selenium": SeleniumEngine,
            "request": SoupEngine,
            "rss": RssEngine
        }
        
        #caller
        self.ENGINE = None
        
        #program metadata
        self.CONTRACTS = all_contracts
        
        #selenium configs
        self.driver = None
        self.selector_map = None
        self.visible_map = None
        
        #request configs
        
        #grand config registry class
        self.ACTION_CONTEXT = None
        
    
    #dependency of url based on selenium/soup/rss
    def _generate_packet(self, engine:str,content)->dict:
      
        packet = {
            "action": self.ACTION_TYPE,
            "uid": Helper.generate_uid(),
            "timestamp": datetime.now().strftime("%d%m%Y %H:%M"),
            "webpage": self.driver.current_url if engine == "selenium" else "",
            "data_present": not any(
                key in entity for entity in content
                for key in ["status", "error_type", "error_message", "error"]
            ),
            "log_message": self.LOG_MESSAGE,
            "response_count": len(content),
            "response": content if content else None
        }

        if self.ACTION_TYPE == "tablist":
            packet["tab_found"] = getattr(self, "TABS_FOUND", [])
            packet["follow_ups"] = [step.get("action") for step in getattr(self, "FOLLOW_UP_ACTIONS", [])if "action" in step]
        
        if self.ACTION_TYPE == "weblist":
            packet["web_links"] = getattr(self, "WEBLINKS", [])
            packet["follow_ups"] = [step.get("action") for step in getattr(self, "FOLLOW_UP_ACTIONS", [])if "action" in step]

        return packet
    
    
    def _perform_action(self, ctx)->None:

        action_type = ctx.ACTION_TYPE
        action = self.ACTION_MAP.get(action_type)
        if action:
            result = action(ctx)
            if result is not None:
                return result
        else:
            self.LOGGER.warning(f"Unknown action type: {self.ACTION_TYPE}")
            
    def execute_contract_steps(self, steps:list):
        """ The function is designed to unpack the code passed per contract,
        determine the _action_ type, set action config, and run the engine 
        to perform the actions by providing a registry

        Args:
            steps (): _description_

        Returns:
            _type_: _description_
        """
        contract_all_data = []
        
        #the generic_action config which is again
        #stored in the config folder
        generic_actions = self.GENERIC_ACTIONS

        self.LOGGER.info(f"Total Action(s) {len(steps)}")

        for _, _action_ in enumerate(steps):
            
            excecution_data = None 
            perform_action  = None #specific action that is supposed to be performed
            
            #================== FETCH ACTION SECTION ==================
            
            if isinstance(_action_, str): #derived from generic_actions config
                
                if _action_ =="QUARANTINE": #early exit if block quarantined
                    self.LOGGER.warning(f"BLOCK IS QUARANTINED.")
                    contract_all_data.append(self._generate_packet({
                        "error_type": "quarantine",
                        "error_message": "Block Quarantined.",
                        "error_from": "ActionExecutor.execute_blocks"
                    }))
                    return contract_all_data
                
                action_key, *content = _action_.split("||") #action_type, action_config
                
                if action_key not in generic_actions:
                    self.LOGGER.warning(f"{action_key} not part of generic_action_keys. Skipping.")
                    continue

                # get default action related conifig 
                # i.e action_website is  = {action, by, value, url, default_wait}
                # this is because 'perform_action' is type(str) so we gotta fetch generic_action
                perform_action = generic_actions[action_key].copy()
                
                #TYPE OF GENERIC ACTIONS + UPDATE THE CONFIG BAED ON INSTRUCTIONS
                # note: write dummy action later
                
                
                #This section is to update the config in the default actions fetched above
                if action_key == "action_website":
                    
                    perform_action.update({"url": content[0]})
                    
                elif action_key == "action_download":
                    
                    by, value, multiple, wait_until,minimize_toggle,scroll = content
                    perform_action.update({
                        "by": by, 
                        "value": value, 
                        "multiple": bool(multiple), 
                        "wait_until": wait_until, 
                        "minimize_toggle":bool(minimize_toggle), 
                        "scroll":bool(scroll) 
                    })
                    
                #note: rest actions dont need user specific config and hence are just
                #"action_screenshot", "action_pdf","action_table"

            elif isinstance(_action_, dict):
                
                # normal key value pair action in config
                perform_action = _action_ 

            else:
                self.LOGGER.warning(f"Unsupported action format: {_action_}")
                continue
            
            
            #================== SET CONFIG + FETCH DATA SECTION ==================
            
            self.ACTION_CONTEXT = ActionContext(perform_action, self.ENGINE) #action specific config setter
            
            excecution_data = self.ENGINE.execute_action(self.ACTION_CONTEXT) # execute the actions
            if excecution_data:
                contract_all_data.append(excecution_data)

        return contract_all_data
    
    
    
    
    # -----------------------------------------------------
    # ENTRY POINT FOR BLOCKEXECUTOR
    # -----------------------------------------------------

    
    def orchestrator(self):
        
        if self.ENGINE not in self.ENGINE_TYPE:
            self.LOGGER.info(f"Unknown Engine. Aborting !!")
            return None
        
        self.LOGGER.info(f"BlockExecutor is Running Orchestrator")
        self.LOGGER.info(f"Initializing {self.ENGINE}")
        
        engine_class = self.ENGINE_TYPE[self.ENGINE]
        
        self.ENGINE = engine_class(self)
        
        self.ENGINE.EngineRunner(self.CONTRACTS)
  
        pass
    
    
class ActionContext:
    
    def __init__(self, _action_:dict, ctx_engine  = None):
    
        DEFAULT_SELENIUM_WAIT = 3
        DEFAULT_SELENIUM_TIMEOUT = 15
        DEFAULT_THROTTLE = 3
        
        self.ACTION_TYPE = _action_.get("action",None)
        #get
        self.BY = self.selector_map(_action_.get("by", "css"))
        self.VALUE = _action_.get("value")
        self.URL = _action_.get("url","https://tinyurl.com/nothing-borgir")
        
        #weblink header
        self.WEBLINKS = _action_.get("web_links",None)
        self.WEBLINKS_HEADER = _action_.get("web_link_headers",[])
        
        # selenium specific
        driver = ctx_engine.driver
        if driver:
            self.COOKIES = {c['name']: c['value'] for c in driver.get_cookies()}
            self.HEADERS = dict(_action_.get("headers", {}))
            self.HEADERS.update({
                "User-Agent":driver.execute_script("return navigator.userAgent"),
                "Referer": driver.current_url
            })
        
        #bs4 soup specific
        # self.SOUP_COOKIES = {c['name']: c['value'] for c in driver.get_cookies()}
        # self.SOUP_HEADERS = dict(_action_.get("headers", {}))
        # self.SOUP_HEADERS.update({
        #     "User-Agent":"",
        #     "Referer": ""
        # })

        
        #API specific
        self.BASE_API = _action_.get("base_api", None)  # can be a list or dict
        self.DOMAIN = _action_.get("domain", None)  # domain for cookies
        self.VERIFY_REQUEST = _action_.get("verify_request", True)
        self.API_RULE = _action_.get("resp_structure",{})
        self.NULL_RESPONSE = _action_.get("null_response",{})
        self.THROTTLE = _action_.get("throttle",DEFAULT_THROTTLE)
        
        #toggle minimize
        self.MINIMIZE_TOGGLE = _action_.get("minimize_toggle",False)
        self.PAGE_SCROLL = _action_.get("scroll",False)
        
        #time
        self.DEFAULT_WAIT = _action_.get("default_wait",DEFAULT_SELENIUM_WAIT)
        self.TIMEOUT = _action_.get("timeout", DEFAULT_SELENIUM_TIMEOUT)
        self.WAIT_UNTIL = _action_.get("wait_until")
        self.WAIT_BY = _action_.get("wait_by", self.BY) #dependent
        self.WAIT_VALUE = _action_.get("wait_value", self.VALUE) #dependent
        self.WAIT_TIMEOUT = _action_.get("wait_timeout", self.TIMEOUT)
            
        #name 
        self.table_name = _action_.get("table_name","table")
        self.html_name = _action_.get('html_name', 'html')
        self.screenshot_name = _action_.get('screenshot_name', 'screenshot')
        self.pdf_name = _action_.get('pdf_name', 'web_pdf')
    
        self.LOG_MESSAGE = _action_.get("log_message", "NA")
        
        self.CLEAN_TABLE = _action_.get("clean_table",True)
        self.REQUIRE_TABLE_TITLE = _action_.get("require_title",True)
        
        
        #field
        self.ATTRIBUTE = _action_.get("attribute")
        self.SCRAPE_FIELDS = _action_.get("scrape_fields")
        self.FOLLOW_UP_ACTIONS =  _action_.get("steps")
        
        self.RUN_FUNCTION = _action_.get("execute",None)
        self.ALLOWED_TABS = _action_.get("allowed_tabs",[])
        
        #save
        self.CONSOLIDATE_SAVE = _action_.get("consolidate_save", False)
        self.MULTIPLE = _action_.get("multiple",False)
        self.FILE_SAVE = _action_.get("file_save",False)
        
        #page pdf
        self.LANDSCAPE = _action_.get("landscape",False)
        self.PRINT_BACKGROUND = _action_.get("print_background",False)
        
        #window
        self.NEW_WINDOW = _action_.get("new_window", False)
        self.RETURN_TO_BASE = _action_.get("return_to_base", False)
        
        #script
        self.SCRIPT_KEY = _action_.get("script_key")
        self.SCRIPT = _action_.get("script")
  
       

    # def _set_contract_params(self, _action_:dict):
         
    #     DEFAULT_SELENIUM_WAIT = 3
    #     DEFAULT_SELENIUM_TIMEOUT = 15
    #     DEFAULT_THROTTLE = 3
        
    #     self.ACTION_TYPE = _action_.get("action",None)
    #     #get
    #     self.BY = self.selector_map(_action_.get("by", "css"))
    #     self.VALUE = _action_.get("value")
    #     self.URL = _action_.get("url","https://tinyurl.com/nothing-borgir")
        
    #     #weblink header
    #     self.WEBLINKS = _action_.get("web_links",None)
    #     self.WEBLINKS_HEADER = _action_.get("web_link_headers",[])
        
    #     # selenium specific
    #     driver = self.driver
    #     self.COOKIES = {c['name']: c['value'] for c in driver.get_cookies()}
    #     self.HEADERS = dict(_action_.get("headers", {}))
    #     self.HEADERS.update({
    #         "User-Agent":driver.execute_script("return navigator.userAgent"),
    #         "Referer": driver.current_url
    #     })
        
    #     #bs4 soup specific
    #     self.SOUP_COOKIES = {c['name']: c['value'] for c in driver.get_cookies()}
    #     self.SOUP_HEADERS = dict(_action_.get("headers", {}))
    #     self.SOUP_HEADERS.update({
    #         "User-Agent":"",
    #         "Referer": ""
    #     })
 
        
    #     #API specific
    #     self.BASE_API = _action_.get("base_api", None)  # can be a list or dict
    #     self.DOMAIN = _action_.get("domain", None)  # domain for cookies
    #     self.VERIFY_REQUEST = _action_.get("verify_request", True)
    #     self.API_RULE = _action_.get("resp_structure",{})
    #     self.NULL_RESPONSE = _action_.get("null_response",{})
    #     self.THROTTLE = _action_.get("throttle",DEFAULT_THROTTLE)
        
    #     #toggle minimize
    #     self.MINIMIZE_TOGGLE = _action_.get("minimize_toggle",False)
    #     self.PAGE_SCROLL = _action_.get("scroll",False)
        
    #     #time
    #     self.DEFAULT_WAIT = _action_.get("default_wait",DEFAULT_SELENIUM_WAIT)
    #     self.TIMEOUT = _action_.get("timeout", DEFAULT_SELENIUM_TIMEOUT)
    #     self.WAIT_UNTIL = _action_.get("wait_until")
    #     self.WAIT_BY = _action_.get("wait_by", self.BY) #dependent
    #     self.WAIT_VALUE = _action_.get("wait_value", self.VALUE) #dependent
    #     self.WAIT_TIMEOUT = _action_.get("wait_timeout", self.TIMEOUT)
            
    #     #name 
    #     self.table_name = _action_.get("table_name","table")
    #     self.html_name = _action_.get('html_name', 'html')
    #     self.screenshot_name = _action_.get('screenshot_name', 'screenshot')
    #     self.pdf_name = _action_.get('pdf_name', 'web_pdf')
      
    #     self.LOG_MESSAGE = _action_.get("log_message", "NA")
        
    #     self.CLEAN_TABLE = _action_.get("clean_table",True)
    #     self.REQUIRE_TABLE_TITLE = _action_.get("require_title",True)
        
        
    #     #field
    #     self.ATTRIBUTE = _action_.get("attribute")
    #     self.SCRAPE_FIELDS = _action_.get("scrape_fields")
    #     self.FOLLOW_UP_ACTIONS =  _action_.get("steps")
        
    #     self.RUN_FUNCTION = _action_.get("execute",None)
    #     self.ALLOWED_TABS = _action_.get("allowed_tabs",[])
        
    #     #save
    #     self.CONSOLIDATE_SAVE = _action_.get("consolidate_save", False)
    #     self.MULTIPLE = _action_.get("multiple",False)
    #     self.FILE_SAVE = _action_.get("file_save",False)
        
    #     #page pdf
    #     self.LANDSCAPE = _action_.get("landscape",False)
    #     self.PRINT_BACKGROUND = _action_.get("print_background",False)
        
    #     #window
    #     self.NEW_WINDOW = _action_.get("new_window", False)
    #     self.RETURN_TO_BASE = _action_.get("return_to_base", False)
        
    #     #script
    #     self.SCRIPT_KEY = _action_.get("script_key")
    #     self.SCRIPT = _action_.get("script")
