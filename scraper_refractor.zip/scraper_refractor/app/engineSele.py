from datetime import datetime
import time, traceback, random, subprocess, re
import pygetwindow as gw #type: ignore
import undetected_chromedriver as uc #type: ignore
from selenium.webdriver.common.by import By #type: ignore
from selenium.webdriver.support.ui import WebDriverWait #type: ignore
from selenium.common.exceptions import TimeoutException #type: ignore
from selenium.webdriver.support import expected_conditions as EC #type: ignore
from selenium.common.exceptions import WebDriverException  # type: ignore

from app.logger import get_global_logger, log_exceptions
from app.utils import Helper
from app.constants import *
from app.actions import (
    downloadElem,textScrape, htmlScrape, selectList,
    clickSave,clickElem, genPdf,genSst, 
    webRedir, httpRequest, injectScript, apiGet,
    tabList, webList, manualAction,tablScrape, inputAction,
    repList, dummyTable
)

class SeleniumEngine:

    def __init__(self, executor):
        
        self.logger = get_global_logger()
        self.DOWNLOAD_FOLDER = data_dir()
        self.HELPER = Helper()
        self.ENGINE_TYPE = "SELENIUM"

        
        self.today = datetime.now()
        self.date = datetime.now().strftime("%Y-%m-%d")
        self.timestamp = datetime.now().strftime("%H%M")

        
        
        self.driver = None
        
        self.PAGE_LOAD_TIMEOUT = 120
        self.RETRIES = 3
        self.RETRY_DELAY = 5
        
        self.BROWSER_WIN_SIZE = 900, 700
        self.BROWSER_WIN_POSI = -800, 100
        
        self.WEBSITE_DOM_WAIT = 40
        
        self.SCROLL_PAGE_TILL = 400

        #specific to each contract
        self.CONTRACT_PARAMS = None 
        self.CONTRACT_DONWLOAD_FOLDER = None 
        
        self.SELENIUM_SELECTOR_MAP =  {
            "css": By.CSS_SELECTOR,
            "xpath": By.XPATH,
            "id": By.ID,
            "name": By.NAME,
            "class": By.CLASS_NAME,
            "tag": By.TAG_NAME,
            "txt":By.LINK_TEXT,
            "ptxt":By.PARTIAL_LINK_TEXT
        }
        
        self.SELENIUM_CONDITION_MAP = {
            "clickable": EC.element_to_be_clickable,
            "visible": EC.visibility_of_element_located,
            "present": EC.presence_of_element_located,
            "invisible": EC.invisibility_of_element_located,
            "attached": EC.element_to_be_selected,
        }
        
        
        #Block Executor Function
        self.BLOCK_EXECUTOR = executor
        self.BLOCK_EXECUTOR.selector_map = self.SELENIUM_SELECTOR_MAP
        self.BLOCK_EXECUTOR.visible_map = self.SELENIUM_CONDITION_MAP
        
        
        #SELENIUM ACTION MAP
        self.ACTION_MAP = {
            "html":  htmlScrape(self),
            "table":  tablScrape(self),
            "text":  textScrape(self),
            "pdf":  genPdf(self),
            "screenshot":  genSst(self),
            "click":  clickElem(self), 
            "click_save":  clickSave(self),
            "website":  webRedir(self),
            "download":  downloadElem(self),
            "redir_pdf":  genPdf(self), 
            "tablist":  tabList(self), 
            "weblist":  webList(self), 
            "replist":  repList(self),
            "http":  httpRequest(self),
            "manual":  manualAction(self),
            "execute_script":  injectScript(self),
            "api_get": apiGet(self),
            "select": selectList(self),
            "input": inputAction(self),
            "dummy":  dummyTable(self)
        }

    # -----------------------------------------------------
    # DRIVER LIFECYCLE
    # -----------------------------------------------------

    #Contract Sepcific Selenium Dependencies 
    @log_exceptions(level="error", return_value=False)
    def create_uc_driver(self, headless=False, minimized=True):
        
        # --headless                       # Run Chrome in headless mode (no GUI)
        # --disable-gpu                    # Disable GPU hardware acceleration
        # --no-sandbox                     # Bypass OS security model (useful in Docker)
        # --disable-dev-shm-usage          # Avoid shared memory issues in containers
        # --start-maximized                # Start browser maximized
        # --window-size=1920,1080          # Set specific window size
        # --incognito                      # Launch in incognito mode
        # --disable-extensions             # Disable all Chrome extensions
        # --disable-blink-features=AutomationControlled  # Hide automation flags
        # --user-data-dir="path"           # Use custom Chrome user profile directory
        # --profile-directory="Profile 2"  # Specify profile folder inside user-data-dir
        # --remote-debugging-port=9222     # Enable remote debugging
        # --lang=en                        # Set browser language
        # --ignore-certificate-errors      # Skip SSL certificate errors
        # --disable-popup-blocking         # Allow popups
        # --disable-infobars               # Hide "Chrome is being controlled..." banner
        
        # chrome_major = self.get_chrome_major_version()
        chrome_major = 144

        options = uc.ChromeOptions()
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--disable-extensions")
        options.add_argument(f"user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_major}.0.0.0 Safari/537.36")
        
        if headless: options.add_argument("--headless=new")

        options.add_experimental_option("prefs", {
            "download.default_directory": self.DOWNLOAD_FOLDER,
            "download.prompt_for_download": False,
            "plugins.always_open_pdf_externally": True,
            "download.directory_upgrade": True,
            "safebrowsing.enabled": True
        })
        

        self.driver = uc.Chrome(
            options=options,
            version_main=chrome_major
        )
        self.driver.set_window_size(self.BROWSER_WIN_SIZE)
        self.driver.set_window_position(self.BROWSER_WIN_POSI)
        if minimized and not headless:
            try:
                time.sleep(1)    
                title = self.driver.title or "data:,"
                for w in gw.getWindowsWithTitle(title):
                    w.minimize()
                    self.logger.info("Chrome window minimized safely.")
                    break
            except Exception as e:
                self.logger.warning(f"Minimize failed, fallback to visible small window: {e}")
    
    @log_exceptions(level="error", return_value=False)    
    def get_website(self, timeout, dom_wait):
        if self.driver:
            try:
                self.driver.set_page_load_timeout(timeout)
                self.driver.get(self.CONTRACT_PARAMS["base_url"])
                self.logger.info("Website Fetched.")
                WebDriverWait(self.driver, dom_wait).until(lambda d: d.execute_script("return document.readyState") in ["interactive", "complete"])
                return
            except Exception:
                self.logger.warning("Page load hung — stopping manually.")
                self.driver.execute_script("window.stop();")
                return

        self.logger.warning(f"Driver not created. Couldnt get website.")
        return
     
    def _restore_window(self):
        """Restore or bring Chrome to front if minimized/tiny."""
        try:
            self.logger.info("Restoring Chrome window...")
            self.driver.set_window_size(self.BROWSER_WIN_SIZE)
            self.driver.set_window_position(self.BROWSER_WIN_POSI)
            title = self.driver.title or "data:,"
            for w in gw.getWindowsWithTitle(title):
                w.activate()
                break
            time.sleep(1)
            self.logger.info("Restored to visible window.")
        except Exception as e:
            self.logger.warning(f"Could not restore window: {e}")

    def _minimize_window(self):
        """Minimize or shrink Chrome after action completes."""
        try:
            self.logger.info("Minimizing Chrome window...")
            title = self.driver.title or "data:,"
            for w in gw.getWindowsWithTitle(title):
                w.minimize()
                break
            time.sleep(1)
            self.logger.info("Chrome minimized again.")
        except Exception as e:
           
            try: #fallback
                self.driver.set_window_size(self.BROWSER_WIN_SIZE)
                self.driver.set_window_position(self.BROWSER_WIN_POSI)
                self.logger.info("Fallback: Chrome shrunk to 900x700.")
            except Exception as e2:
                self.logger.warning(f"Could not minimize or shrink: {e2}")
    
    def _scroll_webpage(self):
        try:
            self.logger.info("Scrolling Page to Load Elements")
            scroll_height = self.driver.execute_script("return document.body.scrollHeight")
            for y in range(0, scroll_height, self.SCROLL_PAGE_TILL):
                self.driver.execute_script(f"window.scrollTo(0,{y});")
                time.sleep(1)
            self.driver.execute_script("window.scrollTo(0,document.body.scrollHeight);")
            time.sleep(2)
        except Exception as e:
            self.logger.warning(f"Auto-scroll Failed: {e}")
            
    #Lifestyle Sepcific Selenium Dependencies
    @log_exceptions(level="error", return_value=False)
    def start_session(self):

        # retries = 3
        # retry_delay = 5

        for attempt in range(self.RETRIES):

            try:
                self.logger.info(f"[SeleniumEngine] Creating Driver (Attempt {attempt+1})")

                self.create_uc_driver(
                    headless=self.metadata.get("headless", False),
                    minimized=self.metadata.get("minimize_selenium", True)
                )
                
                #IMP: assign driver to BlockExecutor object
                self.BLOCK_EXECUTOR.driver = self.driver

                if not self.driver:
                    raise RuntimeError("Driver Creation Returned None")

                self.driver.set_page_load_timeout(
                    self.metadata.get("hero_timeout", self.PAGE_LOAD_TIMEOUT)
                )

                self.logger.info("[SeleniumEngine] Driver created successfully")
                return True

            except WebDriverException as e:

                self.logger.error(f"Driver creation failed: {type(e).__name__}")
                self.logger.error(traceback.format_exc())

        self.logger.critical("Failed to initialize Selenium driver")
        return False

    @log_exceptions(level="error", return_value=False)
    def close_session(self):
        try:
            if self.driver:
                self.driver.quit()
                self.logger.info("[SeleniumEngine] Driver closed")

        except Exception as e:
            self.logger.error(f"Driver close failed: {e}")
            self.logger.error(traceback.format_exc())


    # -----------------------------------------------------
    # CONTRACT PROCESSING
    # -----------------------------------------------------
    
    def process_contract(self, contract: dict):
        
        """ After loading the driver, each contract has to be executed, contract specific configs
            like download_folder, parameters are set here. Then the landing page for driver is loaded.
            Each contract has one or many steps -> which inturn are config, they are unpacked via BlockExecutor,
            their config being set and control of the program being transferred back to BlockExecutor via "execute_contract_steps".
            The data thus fetched after performing all the actions is returned via "scraped_data"
            
        Returns:
            _type_: _description_
        """

        cname = contract.get("contract_name")
        self.logger.info(f"=== Selenium Contract → {cname} ===")
        
        # SET CONTRACT SPECIFIC PARAMS AND UPDATE DOWNLOAD PATH
        self.CONTRACT_PARAMS = contract
        self.CONTRACT_DONWLOAD_FOLDER = self.HELPER.create_dir(self.DOWNLOAD_FOLDER,self.date, contract['contract_name'],f"d{self.timestamp[:-1]}")
        
        self.driver.execute_cdp_cmd(
            "Page.setDownloadBehavior", {
            "behavior": "allow",
            "downloadPath": self.CONTRACT_DONWLOAD_FOLDER
            })
        self.logger.debug(f"Download Folder: {self.CONTRACT_DONWLOAD_FOLDER}")
        
        
        
        #  FETCH THE ACTION DATA AND/OR CATCH EXCEPTIONS
        scraped_data = []
        
        try:
            timeout = contract.get("hero_timeout", self.PAGE_LOAD_TIMEOUT)
            steps_to_perform = contract.get("steps", [])
            self.get_website(timeout)
            # functions to execute all the actions and get the aggregate
            # save those aggregates in final blocks
            data = self.BLOCK_EXECUTOR.execute_contract_steps(steps_to_perform) 
            scraped_data.extend(data)

        except Exception as e:

            self.logger.error( f"[SeleniumEngine] Failed for {cname}: {type(e).__name__}")
            self.logger.error(traceback.format_exc())
            scraped_data = [{
                "error_type": type(e).__name__,
                "error_message": str(e), 
                "error_from": "SeleniumEngine.process_contract"
            }]

        finally:
            if self.driver:
                self.driver.delete_all_cookies()
      

        return {
            "contract_name": cname,
            "contract_code": contract.get("contract_code"),
            "hero_url": contract.get("hero_url"),
            "scraped_data": scraped_data
        }
        
    
    def execute_action(self, ctx):
        
        """ This function exists to execute the action in selenium, "ctx" is the registry of
        all the action specific config required for the action. This is a workflow function
        which basically performs actions one by one like wait, (restore/mininize) window

        Returns:
            _type_: _description_
        """
        
        #not sure why is this being used but we figure out later
        time.sleep(random.uniform(ctx.DEFAULT_WAIT / 1.2, ctx.DEFAULT_WAIT))
        
        #figure out later
        self.ELEMENT = None
        
        #figure out later
        if ctx.MINIMIZE_TOGGLE: 
            self._minimize_window()
        
        #auto scroll
        if ctx.PAGE_SCROLL:
            self._scroll_webpage()
                      
        #perform action
        try:
            self.logger.info(f" ** action : {ctx.ACTION_TYPE} **")

            if ctx.WAIT_UNTIL: #time in seconds

                try:
                    #bascially wait it out until this particular html is present on the web page
                    cond = self.SELENIUM_CONDITION_MAP(ctx.WAIT_UNTIL, ctx.WAIT_BY, ctx.WAIT_VALUE)
                    WebDriverWait(self.driver, ctx.TIMEOUT).until(cond)
                    
                except TimeoutException:
                    
                    page_state = self.driver.execute_script("return document.readyState")
                    html_len = len(self.driver.page_source)
                    console_logs = []
                    try:
                        console_logs = self.driver.get_log("browser")[-3:]
                    except Exception:
                        pass

                    self.logger.error(
                        f"[Timeout] Condition='{ctx.WAIT_UNTIL}', readyState='{page_state}', "
                        f"HTML length={html_len}, ConsoleLogs={console_logs}"
                    )
                    raise 
            
            #each action by default asks for an css/tag/xpath/id/class and the value to look
            #this DOM element this fetched by find is performed the rest of the action on
            
            self.ELEMENT = self.driver.find_element(ctx.BY, ctx.VALUE)
            
            #this function
            content = self.BLOCK_EXECUTOR._perform_action(ctx)

        except Exception as e:
            self.logger.error(f"Error in self.execute: [{type(e).__name__}] {str(e)}")
            self.logger.debug(f"Traceback:\n{traceback.format_exc()}")
            if self.MINIMIZE_TOGGLE: self._minimize_window()
            return self.__generate_packet([{
                "error_type": type(e).__name__,
                "error_message": str(e),
                "error_from": "ActionExecutor.execute"
            }])
            
        if self.MINIMIZE_TOGGLE: self._minimize_window()
        
        unattatched_action = ["website"]
        if _action_.get("action","") in unattatched_action:
            self.logger.info(f"The action not to be attatched in main scrape.")
            return None
        
 
        return self.__generate_packet(content) if content else self.__generate_packet([{
            "error_type": "NoneType",
            "error_message": "No content extracted.",
            "error_from": "ActionExecutor.execute"
        }])
    
    
    # -----------------------------------------------------
    # MAIN ENGINE
    # -----------------------------------------------------

    def EngineRunner(self, contracts: list):
        """ 
        Summary: 
        Args: contracts (list): List of contracts to execute via selenium scraper.
        Returns: results (list): Processes contract after fetching in selenium and returning the list.
        """

        results = [] #stores all the output of the contracts

        if not self.start_session(): #creates driver +  fetches landing website + initalize other data
            self.logger.critical("SeleniumEngine cannot start without driver")
            return results

        for contract in contracts:

            try:
                result = self.process_contract(contract) #collective function to Call SeleniumEngine
                if result:
                    results.append(result)

            except Exception as e:

                self.logger.error(f"[SeleniumEngine] Contract failed: {contract.get('contract_name')}")
                self.logger.debug(traceback.format_exc())

        self.close_session()

        return results
        

class ActionExecutor:
    def __init__(self):
        pass

        
   


    # def get_chrome_major_version(self):
    #     chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

    #     try:
    #         out = subprocess.check_output(
    #             [chrome_path, "--version"],
    #             stderr=subprocess.STDOUT
    #         ).decode()
    #         print(" ", repr(out))

    #         return int(re.search(r"(\d+)\.", out).group(1))
    #     except Exception as e:
    #         raise RuntimeError(f"Could not detect Chrome version: {e}")




    # def get_chrome_major_version(self):
    #     chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

    #     try:
    #         out = subprocess.check_output(
    #             [chrome_path, "--version"],
    #             stderr=subprocess.STDOUT
    #         ).decode()
    #         print(" ", repr(out))

    #         return int(re.search(r"(\d+)\.", out).group(1))
    #     except Exception as e:
    #         raise RuntimeError(f"Could not detect Chrome version: {e}")
    
    