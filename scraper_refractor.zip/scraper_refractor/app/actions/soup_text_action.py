from app.logger import get_global_logger
from app.actions.helper import ActionHelper
import urllib3

def souptextScrape(ctx):

    log = get_global_logger()
    soup = ctx.soup
    scrape_content = []
    
    # if ctx.IGNORE_WARNING:
    #     urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)    
    
    if not soup:
        log.error("[HTML] Soup not initialized.")
        return scrape_content


    if ctx.VALUE:
        elements = soup.select(ctx.VALUE)
        log.info(f"[HTML] Selector: {ctx.VALUE}")
    else:
        log.warning("[HTML] No selector provided.")
        return scrape_content

    if not elements:
        log.warning("[HTML] No elements found.")
        return scrape_content

    log.info(f"[HTML] Elements found: {len(elements)}")


    try:
        # SINGLE MODE
        if not ctx.MULTIPLE:
            scrape_content.append(
                ActionHelper.generate_resp_packet(
                    name=f"{ctx.html_name}_0",
                    header=[],
                    value=str(elements[0]),
                    type="html"
                )
            )
            return scrape_content

        # MULTIPLE MODE
        for i, elem in enumerate(elements):
            scrape_content.append(
                ActionHelper.generate_resp_packet(
                    name=f"{ctx.html_name}_{i}",
                    header=[],
                    value=str(elem),
                    type="html"
                )
            )

    except Exception as e:
        log.error(f"[HTML] Extraction failed: {type(e).__name__} - {e}")

    return scrape_content