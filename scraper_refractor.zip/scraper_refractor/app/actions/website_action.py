from app.logger import get_global_logger

def webRedir(ctx):
    """Navigate to the specified URL in ctx.URL."""
    logger = get_global_logger()
    try:
        logger.info(f"Redirecting to website {ctx.URL}")
        ctx.driver.get(ctx.URL)
    except Exception as e:
        logger.error(f"Unable to redirect: {type(e).__name__} - {e}")
    return []
