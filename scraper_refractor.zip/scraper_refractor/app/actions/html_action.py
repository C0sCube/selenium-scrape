from app.logger import get_global_logger
from app.actions.helper import ActionHelper

def htmlScrape(ctx):
    logger = get_global_logger()
    driver = ctx.driver
    elements = driver.find_elements(ctx.BY, ctx.VALUE) if ctx.MULTIPLE else [driver.find_element(ctx.BY, ctx.VALUE)]

    scrape_content = []
    for idx, elem in enumerate(elements):
        html = elem.get_attribute("outerHTML")
        if not html:
            logger.warning(f"No HTML found for {ctx.VALUE}")
            continue
        scrape_content.append(ActionHelper.generate_resp_packet(
            name=f"{ctx.html_name}_{idx}",
            header="HTML Content",
            value=html,
            type="html"
        ))
    return scrape_content
