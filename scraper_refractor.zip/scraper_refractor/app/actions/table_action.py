# app/actions/table_action.py
from app.logger import get_global_logger
from app.actions.helper import ActionHelper
from selenium.webdriver.common.by import By


def tablScrape(ctx):
    """
    Scrape one or more <table> elements from the current page.
    Automatically detects preceding headers and optionally cleans HTML.
    """
    logger = get_global_logger()
    driver = ctx.driver

    logger.info(f"Scraping tables Using BY={ctx.BY} and VALUE={ctx.VALUE}")
    scrape_content = []
    
    try:
        elements = driver.find_elements(ctx.BY, ctx.VALUE) if ctx.MULTIPLE else [driver.find_element(ctx.BY, ctx.VALUE)]
    except Exception as e:
        logger.error(f"Failed to locate table elements: {e}")
        return scrape_content

   
    if ctx.BY == By.CSS_SELECTOR:
        elements = [elem for elem in elements if elem.tag_name.lower() == "table"]

    logger.info(f"Total tables found: {len(elements)}")


    for idx, elem in enumerate(elements):
        try:
            header_texts = []
            if ctx.REQUIRE_TABLE_TITLE:
                header_texts = ActionHelper._find_preceding_texts(elem)
                logger.info(f"Table {idx} header: {header_texts}")

         
            raw_html = elem.get_attribute("outerHTML")
            final_html = raw_html

            if ctx.CLEAN_TABLE:
                final_html = ActionHelper._clean_raw_table_html(raw_html)
                
            if not final_html.strip():
                logger.info(f"Table {idx} HTML is empty after cleaning. Skipping.")
                continue
        
            scrape_content.append(
                ActionHelper.generate_resp_packet(
                    name=f"{ctx.table_name}_{idx}",
                    header=header_texts,
                    value=final_html,
                    type="table_html",
                )
            )

        except Exception as e:
            logger.error(f"table[{idx}]: {type(e).__name__} - {e}")

    if not scrape_content:
        logger.warning("No valid table content extracted.")
    return scrape_content
