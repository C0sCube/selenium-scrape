from app.logger import get_global_logger
from app.actions.helper import ActionHelper
import urllib3

import pprint

def souptablScrape(ctx):

    log = get_global_logger()
    soup = ctx.soup
    scrape_content = []
    
    print(f"Performing the Soup Table Action.")

    if not soup:
        log.error("Soup not initialized for table scrape.")
        return scrape_content

    if ctx.VALUE:
        elements = soup.select(ctx.VALUE)
        log.info(f"[TABLE] Selector used: {ctx.VALUE}")
    else:
        elements = soup.find_all("table")
        log.info("[TABLE] No selector provided, using all <table> tags")

    log.info(f"[TABLE] Elements found: {len(elements)}")
    print(f"[TABLE] Elements found: {len(elements)}")

    table_counter = 0

    #process elements
    for idx, elem in enumerate(elements):

        try:
            tables = []
            if elem.name == "table":
                tables = [elem]
            else:
                tables = elem.find_all("table")

            if not tables:
                continue

            for t in tables:
                header_texts = [] #extract headers
                if ctx.REQUIRE_TABLE_TITLE:
                    try:
                        header_texts = ActionHelper._find_preceding_texts_soup(t)
                    except Exception as e:
                        log.warning(f"[TABLE] Header extraction failed: {e}")
                        
                scrape_content.append(
                    ActionHelper.generate_resp_packet(
                        name=f"{ctx.table_name}_{table_counter}",
                        header=header_texts,
                        value=str(t),
                        type="table_html",
                    )
                )

                log.info(
                    f"[TABLE] Extracted table_{table_counter} "
                    f"| header={header_texts[:1] if header_texts else 'None'}"
                )

                table_counter += 1

        except Exception as e:
            log.error(
                f"[TABLE] Failed processing element index={idx}: "
                f"{type(e).__name__} - {e}"
            )

    log.info(f"[TABLE] Total tables extracted: {table_counter}")
    
    # pprint.pprint(scrape_content) #works
    return scrape_content