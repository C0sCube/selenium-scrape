# app/actions/weblist_action.py
import time
from selenium.webdriver.support.ui import WebDriverWait
from app.logger import get_global_logger
from app.actions.helper import ActionHelper

def webList(ctx):
    """
    Visit multiple web links sequentially, run follow-up scraping steps for each,
    and attach web_link_headers if available.
    """
    logger = get_global_logger()
    driver = ctx.driver
    follow_ups = ctx.FOLLOW_UP_ACTIONS or []
    tablist_log = ctx.LOG_MESSAGE
    scrape_content = []

    weblinks = []
    if isinstance(ctx.WEBLINKS, list):
        weblinks = ctx.WEBLINKS
    elif isinstance(ctx.WEBLINKS, dict):
        base_url = ctx.WEBLINKS.get("base_url")
        params = ctx.WEBLINKS.get("params", {})
        weblinks = ActionHelper.build_multiple_urls(base_url, params)
    else:
        logger.error("No valid 'WEBLINKS' found for weblist action.")
        return scrape_content

    headers = []
    if ctx.WEBLINKS_HEADER:
        headers = ctx.WEBLINKS_HEADER.split("||")

    logger.info(f"Performing weblist action on {len(weblinks)} website(s).")

    for idx, url in enumerate(weblinks):
        try:
            time.sleep(ctx.THROTTLE)
            driver.get(url)
            logger.notice(f"Navigating to → {url}")

            for step in follow_ups:
                if step.get("wait_until"):
                    condition = ctx._ActionExecutor__get_condition(
                        step["wait_until"], step["by"], step["value"]
                    )
                    WebDriverWait(driver, step["timeout"]).until(condition)
                result = ctx.execute(step)
                if not result:
                    logger.warning(f"No result for step {step['action']} on url {url}")
                    continue

                step_content = result.get("response", [])
                # Attach web_link_header
                if headers and idx < len(headers):
                    web_link_header = headers[idx]
                    for item in step_content:
                        if item.get("data_present"):
                            titles = item.get("title", [])
                            if isinstance(titles, str):
                                titles = [titles]
                            titles.append(web_link_header)
                            item["title"] = titles

                scrape_content.extend(step_content)

        except Exception as e:
            logger.warning(f"Failed to process URL [{idx}]={url}: {e}")

    ctx.ACTION_TYPE = "weblist"
    ctx.LOG_MESSAGE = tablist_log
    ctx.FOLLOW_UP_ACTIONS = follow_ups
    return scrape_content
