from app.logger import get_global_logger
import time

def clickElem(ctx):
    """Clicks an element already stored in executor.ELEMENT."""
    logger = get_global_logger()
    content = []
    try:
        ctx.ELEMENT.click()
        logger.info("Clicked element successfully.")
        time.sleep(ctx.DEFAULT_WAIT)
    except Exception as e:
        logger.error(f"Failed to click element: {type(e).__name__} - {e}")
        
    return content
