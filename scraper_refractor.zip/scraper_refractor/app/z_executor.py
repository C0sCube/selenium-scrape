from datetime import datetime

from app.logger import get_global_logger, log_exceptions
from app.engines.engineSele import SeleniumEngine
from app.engines.engineSoup import SoupEngine
# from app.engineRSS import RssEngine #type: ignore

from app.utils import Helper
from app.constants import *

class ActionRunner:
    
    def __init__(self,engine:str, all_contracts:list, metadata:dict):
        
        #generic caller
        self.log = get_global_logger()
        self.metadata = metadata
        self.GENERIC_ACTIONS = load_gen_config()
        self.HELPER = Helper()
        
        #engine specific caller
        self.engine_name = engine #used to refer SeleniumEngine in methods
        self.engine_type = { 
            "selenium": SeleniumEngine,
            "request": SoupEngine,
            # "rss": RssEngine
        }
        self.ENGINE = None # the OG caller
        
        #list of all the contracts
        self.CONTRACTS = all_contracts
        
        #selenium configs
        self.driver = None
       
        #request configs
        self.soup = None
        #rss configs
        
        #action attribute registry
        self.ACTION_CTX = None


    # -----------------------------------------------------
    # ENTRY POINT FOR BLOCKEXECUTOR
    # -----------------------------------------------------

    
    def orchestrator(self):
        
        if self.engine_name not in self.engine_type:
            self.log.info(f"Unknown Engine Code -> {self.engine_name} Aborting !!")
            return None
        
        # self.log.info(f"BlockExecutor is Running Orchestrator")
        self.log.info(f"Initializing {self.engine_name}")
        
        #here the main object of engine is called.
        engine_cls = self.engine_type[self.engine_name]
        self.ENGINE = engine_cls(self,self.metadata)
        
        res = self.ENGINE.EngineRunner(self.CONTRACTS)
  
        return res
    
    
    #dependency of url based on selenium/soup/rss
    def run_steps(self, steps:list):
        """ The function is designed to unpack the code passed per contract,
        determine the _action_ type, set action config, and run the engine 
        to perform the actions by providing a registry

        Args:
            steps (): Each contract has a few it has to perform, this is that list

        Returns:
            list: All the output of Contracts performed i.e INS_1, INS_2 ..
        """
        contract_all_data = []
        
        #the generic_action config which is again
        #stored in the config folder
        generic_actions = self.GENERIC_ACTIONS

        self.log.info(f"Total Action(s) {len(steps)}")

        for _, _action_ in enumerate(steps):
            
            excecution_data = None 
            perform_action  = dict() #specific action that is supposed to be performed
            
            #================== FETCH ACTION SECTION ==================
            
            if isinstance(_action_, str): #derived from generic_actions config
                
                #Note: the below code should ideally be performed in actionDummy
                # if _action_ =="QUARANTINE": #early exit if block quarantined
                #     self.log.warning(f"BLOCK IS QUARANTINED.")
                #     contract_all_data.append(self._generate_packet_({
                #         "error_type": "quarantine",
                #         "error_message": "Block Quarantined.",
                #         "error_from": "ActionExecutor.execute_blocks"
                #     }))
                #     return contract_all_data
                
                action_key, *content = _action_.split("||") #action_type, action_config
                
                if action_key not in generic_actions:
                    self.log.warning(f"{action_key} not part of generic_action_keys. Skipping.")
                    continue

                # get default action related conifig 
                # i.e action_website is  = {action, by, value, url, default_wait}
                # this is because 'perform_action' is type(str) so we gotta fetch generic_action
                perform_action = generic_actions[action_key].copy()
                
                #TYPE OF GENERIC ACTIONS + UPDATE THE CONFIG BAED ON INSTRUCTIONS
                # note: write dummy action later
                
                
                #This section is to update the config in the default actions fetched above
                if action_key in ["action_website","action_req_table"]:
                    
                    perform_action.update({"url": content[0]})
                    
                elif action_key == "action_download":
                    
                    by, value, multiple, wait_until,minimize_toggle,scroll = content
                    perform_action.update({
                        "by": by, 
                        "value": value, 
                        "multiple": bool(multiple), 
                        "wait_until": wait_until, 
                        "minimize_toggle":bool(minimize_toggle), 
                        "scroll":bool(scroll) 
                    })
                
                    
                #note: rest actions dont need user specific config and hence are just
                #"action_screenshot", "action_pdf","action_table"

            elif isinstance(_action_, dict):
                
                # normal key value pair action in config
                perform_action = _action_ 
                
                print(perform_action)

            else:
                self.log.warning(f"Unsupported action format: {_action_}")
                continue
            
            
            #================== SET CONFIG + FETCH DATA SECTION ==================
            
            self.ACTION_CTX = ExecutionContext(perform_action, self.ENGINE) #action specific config setter
            
            excecution_data = self.ENGINE.execute_step(self.ACTION_CTX) # execute the actions
            if excecution_data:
                contract_all_data.append(excecution_data)

        return contract_all_data
    

    
class ExecutionContext:
    
    def __init__(self, _action_:dict, _engine_):
    
        JUST_WAIT = 4
        DEF_SELENIUM_TIMEOUT = 15
        DEF_REQUEST_TIMEOUT = 30
        DEF_THROTTLE = 3
        
        self.ACTION_TYPE = _action_.get("action",None)
        #get
        self.BY = _action_.get("by", "css") #you gotta save it
        self.VALUE = _action_.get("value")
        self.URL = _action_.get("url","https://tinyurl.com/nothing-borgir")
        
        #weblink header
        self.WEBLINKS = _action_.get("web_links",None)
        self.WEBLINKS_HEADER = _action_.get("web_link_headers",[])
        
        # selenium specific
        self.driver = getattr(_engine_, "driver", None)
        if self.driver:
            self.COOKIES = {c['name']: c['value'] for c in self.driver.get_cookies()}
            self.HEADERS = dict(_action_.get("headers", {}))
            self.HEADERS.update({
                "User-Agent":self.driver.execute_script("return navigator.userAgent"),
                "Referer": self.driver.current_url
            })

            self.TIMEOUT = _action_.get("timeout", DEF_SELENIUM_TIMEOUT)
        
        #bs4 soup specific
        self.soup = getattr(_engine_, "soup", None)
        self.IGNORE_WARNING =  _action_.get("ignore_warning", None) 
        
        if self.soup:
            self.TIMEOUT = _action_.get("timeout", DEF_REQUEST_TIMEOUT)

        # self.SOUP_COOKIES = {c['name']: c['value'] for c in driver.get_cookies()}
        # self.SOUP_HEADERS = dict(_action_.get("headers", {}))
        # self.SOUP_HEADERS.update({
        #     "User-Agent":"",
        #     "Referer": ""
        # })

        #time
        self.JUST_WAIT = _action_.get("default_wait",JUST_WAIT)  
        self.WAIT_UNTIL = _action_.get("wait_until")
        self.WAIT_BY = _action_.get("wait_by", self.BY) #dependent
        self.WAIT_VALUE = _action_.get("wait_value", self.VALUE) #dependent
        self.WAIT_TIMEOUT = _action_.get("wait_timeout", self.TIMEOUT)
        
        #api specific
        self.BASE_API = _action_.get("base_api", None)  # can be a list or dict
        self.DOMAIN = _action_.get("domain", None)  # domain for cookies
        self.VERIFY_REQUEST = _action_.get("verify_request", True)
        self.API_RULE = _action_.get("resp_structure",{})
        self.NULL_RESPONSE = _action_.get("null_response",{})
        self.THROTTLE = _action_.get("throttle",DEF_THROTTLE)
        
        #toggle minimize
        self.MINIMIZE_TOGGLE = _action_.get("minimize_toggle",False)
        self.PAGE_SCROLL = _action_.get("scroll",False)
        
        #name 
        self.table_name = _action_.get("table_name","table")
        self.html_name = _action_.get('html_name', 'html')
        self.screenshot_name = _action_.get('screenshot_name', 'screenshot')
        self.pdf_name = _action_.get('pdf_name', 'web_pdf')
    
        self.LOG_MESSAGE = _action_.get("log_message", "NA")
        
        self.CLEAN_TABLE = _action_.get("clean_table",True)
        self.REQUIRE_TABLE_TITLE = _action_.get("require_title",True)
        
        
        #field
        self.ATTRIBUTE = _action_.get("attribute")
        self.SCRAPE_FIELDS = _action_.get("scrape_fields")
        self.FOLLOW_UP_ACTIONS =  _action_.get("steps")
        
        self.RUN_FUNCTION = _action_.get("execute",None)
        self.ALLOWED_TABS = _action_.get("allowed_tabs",[])
        
        #save
        self.CONSOLIDATE_SAVE = _action_.get("consolidate_save", False)
        self.MULTIPLE = _action_.get("multiple",False)
        self.FILE_SAVE = _action_.get("file_save",False)
        
        #page pdf
        self.LANDSCAPE = _action_.get("landscape",False)
        self.PRINT_BACKGROUND = _action_.get("print_background",False)
        
        #window
        # self.NEW_WINDOW = _action_.get("new_window", False)
        # self.RETURN_TO_BASE = _action_.get("return_to_base", False)
        
        #script
        # self.SCRIPT_KEY = _action_.get("script_key")
        # self.SCRIPT = _action_.get("script")
  
       

# def _set_contract_params(self, _action_:dict):
        
#     DEF_SELENIUM_WAIT = 3
#     DEF_SELENIUM_TIMEOUT = 15
#     DEF_THROTTLE = 3
    
#     self.ACTION_TYPE = _action_.get("action",None)
#     #get
#     self.BY = self.selector_map(_action_.get("by", "css"))
#     self.VALUE = _action_.get("value")
#     self.URL = _action_.get("url","https://tinyurl.com/nothing-borgir")
    
#     #weblink header
#     self.WEBLINKS = _action_.get("web_links",None)
#     self.WEBLINKS_HEADER = _action_.get("web_link_headers",[])
    
#     # selenium specific
#     driver = self.driver
#     self.COOKIES = {c['name']: c['value'] for c in driver.get_cookies()}
#     self.HEADERS = dict(_action_.get("headers", {}))
#     self.HEADERS.update({
#         "User-Agent":driver.execute_script("return navigator.userAgent"),
#         "Referer": driver.current_url
#     })
    
#     #bs4 soup specific
#     self.SOUP_COOKIES = {c['name']: c['value'] for c in driver.get_cookies()}
#     self.SOUP_HEADERS = dict(_action_.get("headers", {}))
#     self.SOUP_HEADERS.update({
#         "User-Agent":"",
#         "Referer": ""
#     })

#     #API specific
#     self.BASE_API = _action_.get("base_api", None)  # can be a list or dict
#     self.DOMAIN = _action_.get("domain", None)  # domain for cookies
#     self.VERIFY_REQUEST = _action_.get("verify_request", True)
#     self.API_RULE = _action_.get("resp_structure",{})
#     self.NULL_RESPONSE = _action_.get("null_response",{})
#     self.THROTTLE = _action_.get("throttle",DEF_THROTTLE)
    
#     #toggle minimize
#     self.MINIMIZE_TOGGLE = _action_.get("minimize_toggle",False)
#     self.PAGE_SCROLL = _action_.get("scroll",False)
    
#     #time
#     self.DEF_WAIT = _action_.get("default_wait",DEF_SELENIUM_WAIT)
#     self.TIMEOUT = _action_.get("timeout", DEF_SELENIUM_TIMEOUT)
#     self.WAIT_UNTIL = _action_.get("wait_until")
#     self.WAIT_BY = _action_.get("wait_by", self.BY) #dependent
#     self.WAIT_VALUE = _action_.get("wait_value", self.VALUE) #dependent
#     self.WAIT_TIMEOUT = _action_.get("wait_timeout", self.TIMEOUT)
        
#     #name 
#     self.table_name = _action_.get("table_name","table")
#     self.html_name = _action_.get('html_name', 'html')
#     self.screenshot_name = _action_.get('screenshot_name', 'screenshot')
#     self.pdf_name = _action_.get('pdf_name', 'web_pdf')
    
#     self.LOG_MESSAGE = _action_.get("log_message", "NA")
    
#     self.CLEAN_TABLE = _action_.get("clean_table",True)
#     self.REQUIRE_TABLE_TITLE = _action_.get("require_title",True)
    
#     #field
#     self.ATTRIBUTE = _action_.get("attribute")
#     self.SCRAPE_FIELDS = _action_.get("scrape_fields")
#     self.FOLLOW_UP_ACTIONS =  _action_.get("steps")
    
#     self.RUN_FUNCTION = _action_.get("execute",None)
#     self.ALLOWED_TABS = _action_.get("allowed_tabs",[])
    
#     #save
#     self.CONSOLIDATE_SAVE = _action_.get("consolidate_save", False)
#     self.MULTIPLE = _action_.get("multiple",False)
#     self.FILE_SAVE = _action_.get("file_save",False)
    
#     #page pdf
#     self.LANDSCAPE = _action_.get("landscape",False)
#     self.PRINT_BACKGROUND = _action_.get("print_background",False)
    
#     #window
#     self.NEW_WINDOW = _action_.get("new_window", False)
#     self.RETURN_TO_BASE = _action_.get("return_to_base", False)
    
#     #script
#     self.SCRIPT_KEY = _action_.get("script_key")
#     self.SCRIPT = _action_.get("script")
