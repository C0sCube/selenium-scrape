

class SoupEngine:
    
    def __init__(self):
        pass
    
    def runner():
        
        pass
    
    def start_session():
        pass
    
    def close_session():
        pass
    
    def get_website():
        pass
    
    
    def process_contract():
        pass