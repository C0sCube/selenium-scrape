import os
from app.utils import Helper

helper = Helper()
root_dir = os.path.dirname(os.path.dirname(__file__))
path_root = os.path.join(root_dir,r"paths.json")
  
def create_dir(root_path: str, *args) -> str:
    full_path = os.path.join(root_path, *args)
    if os.path.exists(full_path):
        return full_path
    os.makedirs(full_path, exist_ok=True)
    return full_path


def get_paths():
    return helper.load_json(path_root)

def output_path():
    return helper.load_json(path_root)["output"]

def get_root_dir():
    return helper.load_json(path_root)["root"]


def load_config():
    path = os.path.join(root_dir,"configs","bse.json5")
    return helper.load_json5(path)
    
def load_gen_config():
    path = os.path.join(root_dir,"configs","gen_config.json5")
    return helper.load_json5(path)


def session_dir():
    out_dir = output_path()
    return create_dir(out_dir,"session")

def data_dir():
    out_dir = output_path()
    return create_dir(out_dir,"data")

def log_dir():
    out_dir = output_path()
    return create_dir(out_dir,"log")

def config_schedule():
    paths = helper.load_json(path_root)
    return paths.get("config_schedule")

def config_mail():
    paths = helper.load_json(path_root)
    return paths.get("config_mail")


# PVT_BANK_CODES = [f"PVB_{i}" for i in range(1,23)]
# PUB_BANK_CODES = [f"PSB_{i}" for i in range(1,13)]
# FRN_BANK_CODES = [f"FRB_{i}" for i in range(1,11)]
# SFB_BANK_CODES = [f"SFB_{i}" for i in range(1,12)]
# ALL_BANK_CODES = [f"PSB_{i}" for i in range(1,13)]+["PVB_22"]+[f"PVB_{i}" for i in range(1,22)]


