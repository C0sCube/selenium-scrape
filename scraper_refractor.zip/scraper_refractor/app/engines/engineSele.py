from datetime import datetime
import time, traceback, random, sys, os
import pygetwindow as gw #type: ignore
import undetected_chromedriver as uc #type: ignore



#selenium imports
from selenium.webdriver.common.by import By #type: ignore
from selenium.webdriver.support.ui import WebDriverWait #type: ignore
from selenium.webdriver.support import expected_conditions as EC #type: ignore
from selenium.common.exceptions import (
    TimeoutException, 
    WebDriverException 
) #type: ignore

# root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
# sys.path.append(root_dir)


from app.logger import get_global_logger, log_exceptions
from app.utils import Helper
from app.constants import *
from app.actions import (
    downloadElem,textScrape, htmlScrape, selectList,
    clickSave,clickElem, genPdf,genSst, 
    webRedir, httpRequest, injectScript, apiGet,
    tabList, webList, manualAction,tablScrape, inputAction,
    repList, dummyTable
)

class SeleniumEngine:

    def __init__(self, executor,metadata:dict):
        
        self.log = get_global_logger()
        self.HELPER = Helper()
        self.metadata = metadata
        self.r_dir = self.metadata["runtime_dir"]
        self.engine_type = "selenium"
        
        #contract specific
        self.CONTRACT_PARAMS = None 
        self.CONTRACT_DOWN_FLDR = None 
        
        #Block Executor Function
        self.BLOCK_EXECUTOR = executor        
        
        #selenium specific
        self.driver = None # the OG handler
        self.header_args = self.metadata["headers"]["driver"]
        self.SELECTOR_MAP =  {
            "css": By.CSS_SELECTOR,
            "xpath": By.XPATH,
            "id": By.ID,
            "name": By.NAME,
            "class": By.CLASS_NAME,
            "tag": By.TAG_NAME,
            "txt":By.LINK_TEXT,
            "ptxt":By.PARTIAL_LINK_TEXT
        }
        
        self.CONDITION_MAP = {
            "clickable": EC.element_to_be_clickable,
            "visible": EC.visibility_of_element_located,
            "present": EC.presence_of_element_located,
            "invisible": EC.invisibility_of_element_located,
            "attached": EC.element_to_be_selected,
        }
        
        self.ACTION_MAP = {
            "html":  htmlScrape,
            "table":  tablScrape,
            "text":  textScrape,
            "pdf":  genPdf,
            "screenshot":  genSst,
            "click":  clickElem, 
            "click_save":  clickSave,
            "website":  webRedir,
            "download":  downloadElem,
            "redir_pdf":  genPdf, 
            "tablist":  tabList, 
            "weblist":  webList, 
            "replist":  repList,
            "http":  httpRequest,
            "manual":  manualAction,
            "execute_script":  injectScript,
            "api_get": apiGet,
            "select": selectList,
            "input": inputAction,
            "dummy":  dummyTable
        }
        
        self.PAGE_LOAD_TIMEOUT = 120
        self.RETRIES = 3
        self.RETRY_DELAY = 5
        self.BROWSER_WIN_SIZE = 900, 700
        self.BROWSER_WIN_POSI = -800, 100
        self.WEBSITE_DOM_WAIT = 40
        self.SCROLL_PAGE_TILL = 400

    # -----------------------------------------------------
    # DRIVER LIFECYCLE
    # -----------------------------------------------------

    #Contract Sepcific Selenium Dependencies 
    def create_uc_driver(self, opt_args:list,headless=False, minimized=True):
        
        # --headless                       # Run Chrome in headless mode (no GUI)
        # --disable-gpu                    # Disable GPU hardware acceleration
        # --no-sandbox                     # Bypass OS security model (useful in Docker)
        # --disable-dev-shm-usage          # Avoid shared memory issues in containers
        # --start-maximized                # Start browser maximized
        # --window-size=1920,1080          # Set specific window size
        # --incognito                      # Launch in incognito mode
        # --disable-extensions             # Disable all Chrome extensions
        # --disable-blink-features=AutomationControlled  # Hide automation flags
        # --user-data-dir="path"           # Use custom Chrome user profile directory
        # --profile-directory="Profile 2"  # Specify profile folder inside user-data-dir
        # --remote-debugging-port=9222     # Enable remote debugging
        # --lang=en                        # Set browser language
        # --ignore-certificate-errors      # Skip SSL certificate errors
        # --disable-popup-blocking         # Allow popups
        # --disable-infobars               # Hide "Chrome is being controlled..." banner
        
        # chrome_major = self.get_chrome_major_version()

        
        chrome_major = 144

        options = uc.ChromeOptions()
        for args in opt_args:
            options.add_argument(args)

        if headless: options.add_argument("--headless=new")

        options.add_experimental_option("prefs", {
            "download.default_directory": self.r_dir,
            "download.prompt_for_download": False,
            "plugins.always_open_pdf_externally": True,
            "download.directory_upgrade": True,
            "safebrowsing.enabled": True
        })
        

        self.driver = uc.Chrome(
            options=options,
            # version_main=chrome_major
        )
        # self.driver.set_window_size(self.BROWSER_WIN_SIZE)
        self.driver.set_window_position(-800, 100)
        if minimized and not headless:
            try:
                time.sleep(1)    
                title = self.driver.title or "data:,"
                for w in gw.getWindowsWithTitle(title):
                    w.minimize()
                    self.log.info("Chrome window minimized safely.")
                    break
            except Exception as e:
                self.log.warning(f"Minimize failed, fallback to visible small window: {e}")
    
    # @log_exceptions(level="error", return_value=False)    
    # def get_website(self, timeout, dom_wait):
    #     if self.driver:
    #         try:
    #             self.driver.set_page_load_timeout(timeout)
    #             self.driver.get(self.CONTRACT_PARAMS["base_url"])
    #             self.log.info("Website Fetched.")
    #             WebDriverWait(self.driver, dom_wait).until(
    #                 lambda d: d.execute_script("return document.readyState") == "complete"
    #             )
    #             return
    #         # except Exception:
    #         #     self.log.warning("Page load hung — stopping manually.")
    #         #     self.driver.execute_script("window.stop();")
    #         #     return
    #         except Exception:
    #             self.log.warning("Page load hung — stopping manually.")
    #             self.driver.execute_script("window.stop();")
    #             time.sleep(3)

    #             try:
    #                 WebDriverWait(self.driver, 10).until(
    #                     lambda d: d.execute_script("return document.readyState") in ["interactive", "complete"]
    #                 )
    #             except:
    #                 self.log.warning("Fallback DOM wait failed")

    #     self.log.warning(f"Driver not created.")
    #     return

    def get_website(self, timeout, dom_wait):

        # --- safety check ---
        if not self.driver:
            self.log.error("Driver not initialized before navigation.")
            return
        
        website = self.CONTRACT_PARAMS["hero_url"]
        if not website:
            self.log.critical("Hero Website Not Attatched.")
            return

        try:
            # --- load page ---
            self.log.info(f"Hero Url: {website}")
            self.driver.set_page_load_timeout(timeout)
            self.driver.get(website)

            self.log.info("Website requested, waiting for full load...")

            # --- normal wait (ideal case) ---
            WebDriverWait(self.driver, dom_wait).until(
                lambda d: d.execute_script("return document.readyState") == "complete"
            )

            self.log.info("Website fully loaded (complete).")
            return

        except Exception:
            # --- fallback for infinite loading sites ---
            self.log.warning("Page load hung — stopping manually.")
            self.driver.execute_script("window.stop();")
            time.sleep(3)

            try:
                WebDriverWait(self.driver, 10).until(
                    lambda d: d.execute_script("return document.readyState") in ["interactive", "complete"]
                )
                self.log.info("Page reached interactive state — proceeding.")
            except Exception:
                self.log.warning("Fallback DOM wait failed — proceeding anyway.")

            return  # ✅ CRITICAL FIX (prevents false 'Driver not created')

    def _restore_window(self):
        """Restore or bring Chrome to front if minimized/tiny."""
        try:
            self.log.info("Restoring Chrome window...")
            self.driver.set_window_size(900, 700)
            self.driver.set_window_position(-800, 100)
            title = self.driver.title or "data:,"
            for w in gw.getWindowsWithTitle(title):
                w.activate()
                break
            time.sleep(1)
            self.log.info("Restored to visible window.")
        except Exception as e:
            self.log.warning(f"Could not restore window: {e}")

    def _minimize_window(self):
        """Minimize or shrink Chrome after action completes."""
        try:
            self.log.info("Minimizing Chrome window...")
            title = self.driver.title or "data:,"
            for w in gw.getWindowsWithTitle(title):
                w.minimize()
                break
            time.sleep(1)
            self.log.info("Chrome minimized again.")
        except Exception as e:
           
            try: #fallback
                self.driver.set_window_size(900, 700)
                self.driver.set_window_position(-800, 100)
                self.log.info("Fallback: Chrome shrunk to 900x700.")
            except Exception as e2:
                self.log.warning(f"Could not minimize or shrink: {e2}")
    
    def _scroll_webpage(self):
        try:
            self.log.info("Scrolling Page to Load Elements")
            scroll_height = self.driver.execute_script("return document.body.scrollHeight")
            for y in range(0, scroll_height, self.SCROLL_PAGE_TILL):
                self.driver.execute_script(f"window.scrollTo(0,{y});")
                time.sleep(1)
            self.driver.execute_script("window.scrollTo(0,document.body.scrollHeight);")
            time.sleep(2)
        except Exception as e:
            self.log.warning(f"Auto-scroll Failed: {e}")
            
    #Lifestyle Sepcific Selenium Dependencies
    @log_exceptions(level="error", return_value=False)
    def start_session(self):

        # retries = 3
        # retry_delay = 5

        for attempt in range(self.RETRIES):

            try:
                self.log.info(f"[SeleniumEngine] Creating Driver (Attempt {attempt+1})")

                self.create_uc_driver(
                    self.header_args,
                    self.metadata.get("sel_headless", False),
                    self.metadata.get("sel_minimize", False)
                )
                
                if not self.driver:
                    raise RuntimeError("Driver Creation Returned None")

                self.driver.set_page_load_timeout(
                    self.metadata.get("hero_timeout", self.PAGE_LOAD_TIMEOUT)
                )

                self.log.info("[SeleniumEngine] Driver created successfully")
                return True

            except WebDriverException as e:

                self.log.error(f"Driver creation failed: {type(e).__name__}")
                self.log.error(traceback.format_exc())

        self.log.critical("Failed to initialize Selenium driver")
        return False

    @log_exceptions(level="error", return_value=False)
    def close_session(self):
        try:
            if self.driver:
                self.driver.quit()
                self.log.info("[SeleniumEngine] Driver closed")

        except Exception as e:
            self.log.error(f"Driver close failed: {e}")
            self.log.error(traceback.format_exc())


    # -----------------------------------------------------
    # CONTRACT PROCESSING
    # -----------------------------------------------------
    
    def _perform_action_(self, ctx)->None:

        action_type = ctx.ACTION_TYPE
        action = self.ACTION_MAP.get(action_type)
        if action:
            result = action(ctx)
            if result is not None:
                return result
        else:
            self.log.warning(f"Unknown action type: {action_type}")
            
    def _generate_packet_(self, ctx, content)->dict:
      
        packet = {
            "action": ctx.ACTION_TYPE,
            "uid": Helper.generate_uid(),
            "timestamp": datetime.now().strftime("%d%m%Y %H:%M"),
            "webpage": self.driver.current_url,
            "data_present":  any(
                key in item
                for item in (content or [])
                for key in ["status", "error_type", "error_message", "error"]
            ),
            # "log_message": ctx.LOG_MESSAGE,
            "response_count": len(content),
            "response": content if content else None
        }

        if ctx.ACTION_TYPE == "tablist":
            packet["tab_found"] = getattr(self, "TABS_FOUND", [])
            packet["follow_ups"] = [step.get("action") for step in getattr(self, "FOLLOW_UP_ACTIONS", []) if "action" in step]
        
        if ctx.ACTION_TYPE == "weblist":
            packet["web_links"] = getattr(self, "WEBLINKS", [])
            packet["follow_ups"] = [step.get("action") for step in getattr(self, "FOLLOW_UP_ACTIONS", []) if "action" in step]

        return packet
    
    def process_contract(self, contract: dict):
        
        """ After loading the driver, each contract has to be executed, contract specific configs
            like download_folder, parameters are set here. Then the landing page for driver is loaded.
            Each contract has one or many steps -> which inturn are config, they are unpacked via BlockExecutor,
            their config being set and control of the program being transferred back to BlockExecutor via "execute_contract_steps".
            The data thus fetched after performing all the actions is returned via "scraped_data"
            
        Returns:
            _type_: _description_
        """

        cname = contract.get("contract_name")
        self.log.info(f"=== Selenium Contract → {cname} ===")
        
        self.CONTRACT_PARAMS = contract
        self.CONTRACT_DOWN_FLDR = create_dir( self.r_dir,"download", cname)
        
        self.driver.execute_cdp_cmd(
            "Page.setDownloadBehavior", {
            "behavior": "allow",
            "downloadPath": self.CONTRACT_DOWN_FLDR
            })
        # self.log.info(f"Download Folder: {self.CONTRACT_DONWLOAD_FOLDER}")
        
        
        #  FETCH THE ACTION DATA AND/OR CATCH EXCEPTIONS
        scraped_data = []
        
        try:
            timeout = contract.get("hero_timeout", self.PAGE_LOAD_TIMEOUT)
            dom_wait =  self.WEBSITE_DOM_WAIT
            steps_to_perform = contract.get("steps", [])
            self.log.info(f"Driver inside process_contract: {self.driver}")
            self.get_website(timeout,dom_wait)
            # functions to execute all the actions and get the aggregate
            # save those aggregates in final blocks
            data = self.BLOCK_EXECUTOR.run_steps(steps_to_perform) 
            scraped_data.extend(data)

        except Exception as e:

            self.log.error( f"[SeleniumEngine] Failed for {cname}: {type(e).__name__}")
            self.log.error(traceback.format_exc())
            scraped_data = [{
                "error_type": type(e).__name__,
                "error_message": str(e), 
                "error_from": "SeleniumEngine.process_contract"
            }]

        finally:
            if self.driver:
                self.driver.delete_all_cookies()
      

        return {
            "contract_name": cname,
            "contract_code": contract.get("contract_code"),
            "hero_url": contract.get("hero_url"),
            "scraped_data": scraped_data
        }
        
    def execute_step(self, ctx):
        
        """ This function exists to execute the action in selenium, "ctx" is the registry of
        all the action specific config required for the action. This is a workflow function
        which basically performs actions one by one like wait, (restore/mininize) window

        Returns:
            _type_: _description_
        """
        
        self.log.info(f" ** action : {ctx.ACTION_TYPE} **") 
        time.sleep(random.uniform(ctx.JUST_WAIT / 1.2, ctx.JUST_WAIT))
        
        #selenium
        ctx.BY = self.SELECTOR_MAP[str(ctx.BY)]
        if ctx.WAIT_BY:
            ctx.WAIT_BY = self.SELECTOR_MAP.get(str(ctx.WAIT_BY), ctx.BY)
        
        content = None #the collective result of the current action
        
        try:
            
            #figure out later
            if ctx.MINIMIZE_TOGGLE: 
                self._minimize_window()

            #auto scroll
            if ctx.PAGE_SCROLL:
                self._scroll_webpage()
                        
            if ctx.WAIT_UNTIL and ctx.WAIT_VALUE: #time in seconds

                try:
                    #bascially wait it out until this particular html is present on the web page
                    cond_fn = self.CONDITION_MAP.get(ctx.WAIT_UNTIL)
                    wait_by = ctx.WAIT_BY or ctx.BY
                    
                    if not cond_fn:
                        raise ValueError(f"Invalid wait condition: {ctx.WAIT_UNTIL}")

                    cond = cond_fn((wait_by, ctx.WAIT_VALUE))

                    WebDriverWait(self.driver, ctx.WAIT_TIMEOUT).until(cond)
                    
                except TimeoutException:
                    
                    page_state = self.driver.execute_script("return document.readyState")
                    html_len = len(self.driver.page_source)
                    console_logs = []
                    try:
                        console_logs = self.driver.get_log("browser")[-3:]
                    except Exception:
                        pass

                    self.log.error(
                        f"[Timeout] Condition='{ctx.WAIT_UNTIL}', readyState='{page_state}', "
                        f"HTML length={html_len}, ConsoleLogs={console_logs}"
                    )
                    raise 
            
            #each action by default asks for an css/tag/xpath/id/class and the value to look
            #this DOM element this fetched by find is performed the rest of the action on
            
            self.ELEMENT = None
            
            self.ELEMENT = self.driver.find_element(ctx.BY, ctx.VALUE)
            
            #this function
            content = self._perform_action_(ctx)

        except Exception as e:
            self.log.error(f"Error in self.execute: [{type(e).__name__}] {str(e)}")
            self.log.debug(f"Traceback:\n{traceback.format_exc()}")
            
            if ctx.MINIMIZE_TOGGLE: 
                self._minimize_window()
            return self._generate_packet_(
                ctx,
                [{
                    "error_type": type(e).__name__,
                    "error_message": str(e),
                    "error_from": "ActionExecutor.execute"
                }]
            )
        
        
        #figure out later  
        if ctx.MINIMIZE_TOGGLE: 
            self._minimize_window()
        
        if content:
            return self._generate_packet_(ctx,content)
        

        return self._generate_packet_(
            ctx,
            [{
                "error_type": "NoneType",
                "error_message": "No content extracted.",
                "error_from": "ActionExecutor.execute_step"
            }]
        )
    
    
    # -----------------------------------------------------
    # MAIN ENGINE
    # -----------------------------------------------------

    def EngineRunner(self, contracts: list):
        """ 
        Summary: 
        Args: contracts (list): List of contracts to execute via selenium scraper.
        Returns: results (list): Processes contract after fetching in selenium and returning the list.
        """

        results = [] #stores all the output of the contracts

        if not self.start_session(): #creates driver +  fetches landing website + initalize other data
            self.log.critical("SeleniumEngine cannot start without driver")
            return results

        for contract in contracts:

            try:
                result = self.process_contract(contract) #collective function to Call SeleniumEngine
                if result:
                    results.append(result)

            except Exception as e:

                self.log.error(f"[SeleniumEngine] Contract failed: {contract.get('contract_name')}")
                self.log.debug(traceback.format_exc())

        self.close_session()

        return results
        
    
   


    # def get_chrome_major_version(self):
    #     chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

    #     try:
    #         out = subprocess.check_output(
    #             [chrome_path, "--version"],
    #             stderr=subprocess.STDOUT
    #         ).decode()
    #         print(" ", repr(out))

    #         return int(re.search(r"(\d+)\.", out).group(1))
    #     except Exception as e:
    #         raise RuntimeError(f"Could not detect Chrome version: {e}")




    # def get_chrome_major_version(self):
    #     chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

    #     try:
    #         out = subprocess.check_output(
    #             [chrome_path, "--version"],
    #             stderr=subprocess.STDOUT
    #         ).decode()
    #         print(" ", repr(out))

    #         return int(re.search(r"(\d+)\.", out).group(1))
    #     except Exception as e:
    #         raise RuntimeError(f"Could not detect Chrome version: {e}")
    
    