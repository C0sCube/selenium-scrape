import re, os,sys,time, random
import urllib3
import requests
import traceback
from bs4 import BeautifulSoup
from datetime import datetime, timedelta

# root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
# sys.path.append(root_dir)

from app.logger import get_global_logger, log_exceptions
from app.utils import Helper
from app.constants import *
from app.actions import (
    souptablScrape, souptextScrape,
    souphtmlScrape
)

class SoupEngine:
    
    def __init__(self, executor, metadata:dict):
        
        self.log = get_global_logger()
        self.metadata = metadata
        self.r_dir = self.metadata["runtime_dir"]
        self.HELPER = Helper()
        self.engine_type = "request"
        
        self.session = None
        self.soup = None
        
        #contract specific
        self.CONTRACT_PARAMS = None 
        self.CONTRACT_DOWN_FLDR = None 
               
        self.BLOCK_EXECUTOR = executor
        
        self.ACTION_MAP = {
            "table": souptablScrape,
            "html": souphtmlScrape,
            "text":souptextScrape
        }
    
    # -----------------------------------------------------
    # DRIVER LIFECYCLE
    # -----------------------------------------------------
        
    def start_session(self):
        self.session = requests.Session()
        return True

    def close_session(self):
        if hasattr(self, "session"):
            self.session.close()
    
    def get_website():
        pass
    
    
    # -----------------------------------------------------
    # CONTRACT PROCESSING
    # -----------------------------------------------------
    
    def _generate_packet_(self,ctx, content)->dict:
        packet = {
            "action": ctx.ACTION_TYPE,
            "uid": Helper.generate_uid(),
            "timestamp": datetime.now().strftime("%d%m%Y %H:%M"),
            "webpage": ctx.URL,
            "data_present": not any(
                key in item
                for item in (content or [])
                for key in ["status", "error_type", "error_message", "error"]
            ),
            # "log_message": None,
            "response_count": len(content) if content else 0,
            "response": content if content else None
        }

        return packet

    def _get_soup(self, ctx):

        url = ctx.URL
        verify = ctx.VERIFY_REQUEST
        timeout = ctx.TIMEOUT

        if not url and not self.soup:
            raise RuntimeError("No URL provided and no cached soup available.")

        if url:
            try:
                resp = self.session.get(url, timeout=timeout, verify=verify)

                if resp.status_code != 200:
                    self.log.error(f"[Soup] HTTP {resp.status_code} for {url}")
                    return BeautifulSoup("", "html.parser")

                soup = BeautifulSoup(resp.text, "html.parser")

                if getattr(ctx, "REUSE_PAGE", False):
                    self.soup = soup

                self.log.info(f"[Soup] Fetched URL: {url}")
                return soup

            except Exception as e:
                self.log.error(f"[Soup] Request failed: {type(e).__name__} - {e}")
                return BeautifulSoup("", "html.parser")

        return self.soup

    def _perform_action_(self, ctx):
        
        if ctx.IGNORE_WARNING: #ignore warnings
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        action_type = ctx.ACTION_TYPE
        action = self.ACTION_MAP.get(action_type)
        self.log.info(f"Running Action: {action_type}")
        
        # prepare soup (shared dependency)
        soup = self._get_soup(ctx)
        ctx.soup = soup   # inject into context

        if not action:
            self.log.warning(f"Unknown action type: {action_type}")
            return []

        try:
            result = action(ctx)
            self.log.info(f"[Soup] Action '{action_type}' extracted {len(result)} items")
            return result

        except Exception as e:
            self.log.error(f"[ACTION FAILED] {action_type}: {type(e).__name__} - {e}")
            return []
        
    def process_contract(self, contract:dict):

        cname = contract.get("contract_name")
        self.log.info(f"=== Soup Contract → {cname} ===")

        self.CONTRACT_PARAMS = contract
        
        hero_url = contract.get("hero_url")
        hero_timeout = contract.get("hero_timeout")
        if hero_url:
            try:
                resp = self.session.get(hero_url, timeout=hero_timeout)
                self.soup = BeautifulSoup(resp.text, "html.parser")
                self.log.info(f"[Soup] Base page loaded: {hero_url}")
                           
            except Exception as e:
                self.log.warning(f"[Soup] Base load failed: {e}")
                
        steps_to_perform = contract.get("steps", [])

        data = self.BLOCK_EXECUTOR.run_steps(steps_to_perform)

        return {
            "contract_name": cname,
            "contract_code": contract.get("contract_code"),
            "hero_url": contract.get("hero_url"),
            "scraped_data": data
        }
            
    def execute_step(self, ctx):
        """ This function exists to execute the action in selenium, "ctx" is the registry of
        all the action specific config required for the action. This is a workflow function
        which basically performs actions one by one like wait, (restore/mininize) window

        Returns:
            _type_: _description_
        """  
        self.log.info(f" ** action : {ctx.ACTION_TYPE} **")
        time.sleep(random.uniform(ctx.JUST_WAIT / 1.2, ctx.JUST_WAIT))
        
        content = self._perform_action_(ctx)

        return self._generate_packet_(ctx, content)
        
    # -----------------------------------------------------
    # MAIN ENGINE
    # -----------------------------------------------------
    @log_exceptions(level="error", return_value=False)
    def EngineRunner(self, contracts: list):

        results = []

        # optional session (good practice)
        self.start_session()

        for contract in contracts:
            try:
                result = self.process_contract(contract)
                if result:
                    results.append(result)

            except Exception as e:
                self.log.error(f"[SoupEngine] Contract failed: {contract.get('contract_name')}")
                self.log.debug(traceback.format_exc())

        self.close_session()

        return results