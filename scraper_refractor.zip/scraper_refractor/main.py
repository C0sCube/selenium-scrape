# app/main.py

import os
import traceback
from datetime import datetime

from app.constants import load_config, log_dir
from app.utils import Helper
from app.logger import get_global_logger, setup_logger
from app.z_scraper import ScraperOrchestrator


def run():
    logger = get_global_logger()
    logger.info("=" * 80)
    logger.info("STARTING SCRAPER PIPELINE")
    helper = Helper()

    try:
        path = r"C:\Users\rando\Office Projects\scraper_refractor\configs\sample.json5"
        config = helper.load_json5(path)
        # logger.info("Config loaded successfully")

        orchestrator = ScraperOrchestrator(config)

        # split contracts by engine
        orchestrator.ReadContracts()
        
        orchestrator.RunContracts()

        final_output = orchestrator.OUTPUT_JSON
        raw_path = orchestrator.paths["raw"]
        Helper.save_json(final_output, raw_path)

        logger.info(f"Raw cache saved → {raw_path}")

        # orchestrator.process_cache(final_output)

        orchestrator.create_scrape_report(
            cache_data=final_output,
            report_type="pdf",   # "pdf" | "xlsx" | "both"
            rewrite=True
        )

        logger.info("SCRAPER PIPELINE COMPLETED SUCCESSFULLY")

    except Exception as e:
        logger.critical(f"MAIN PIPELINE FAILED: {type(e).__name__} - {e}")
        logger.error(traceback.format_exc())


if __name__ == "__main__":
    l_dir = log_dir()
    logger = setup_logger("scrape_log",l_dir, make_global=True)    
    run()