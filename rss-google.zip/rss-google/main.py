from datetime import datetime
import os


from app.constants import get_log_dir, get_sch_config
from app.logger import setup_logger, set_global_logger
from app.mailer import Mailer
from app.nse_rss import news_run_handler
from app.schedular import scheduler_loop


PROGRAM_NAME = "500 Company News Google API"

def program_handler(logger, mailer: Mailer):
    start_time = datetime.now()
    date_str = start_time.strftime('%d-%m-%y')
    send_mail =  mailer.SEND_MAIL

    try:

        logger.info(f"Starting scheduled run at {date_str} {start_time.strftime('%H:%M')}")
        if send_mail:
            mailer.start_mail(program=f"{PROGRAM_NAME}: {date_str}", dev=True)
        
        zip_path = news_run_handler()
        
        if not (zip_path and os.path.exists(zip_path)):
            logger.error("Zip file missing after successful run.")
            if send_mail:
                mailer.fatal_error_mail(
                    program=f"{PROGRAM_NAME}: {date_str}",
                    custom_msg="Zip file not generated.",
                    error_message="Run completed but zip file missing.",
                    dev=True
                )
            return

        if send_mail:
            mailer.end_mail(
                program=f"{PROGRAM_NAME}: {date_str}",
                attachments=[zip_path],
                dev=False
            )
        
        duration = (datetime.now() - start_time).total_seconds()
        logger.info(f"Run completed in {duration:.2f} seconds.")
    

    except Exception as e:
        logger.exception("Fatal error during program_handler")
        if send_mail:
            mailer.fatal_error_mail(
                program=f"{PROGRAM_NAME}: {date_str}",
                custom_msg="Fatal Error",
                error_message="No zip file was generated.",
                dev=True
            )


def main():
    logger = setup_logger(
        "watcher",
        log_dir=get_log_dir(),
        log_level=12
    )
    set_global_logger(logger)
    mailer = Mailer()

    logger.info("Running Program to fetch News via Google API.")
    sch_data = get_sch_config()
   
    scheduler_loop(
        logger,
        lambda: program_handler(logger, mailer),
        sch_data["schedule_days"],
        sch_data["schedule_times"]
    )


if __name__ == "__main__":
    main()
    