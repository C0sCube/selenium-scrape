import os,json

root_dir = os.path.dirname(os.path.dirname(__file__))

path_dir = os.path.join(root_dir,r"paths.json")

def load_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
        
def create_dir(root_path: str, *args) -> str:
    full_path = os.path.join(root_path, *args)
    os.makedirs(full_path, exist_ok=True)
    return full_path


def get_root_dir():
    f = load_json(path_dir)
    return f["root_dir"]

def get_output_dir():
    f = load_json(path_dir)
    return f["output_path"]

def get_log_dir():
    out_dir = get_output_dir()
    return os.path.join(out_dir,"log")

def get_company_path():
    f = get_root_dir()
    return os.path.join(f,"doc","List of Companies.xlsx")

def get_api_config():
    f = get_root_dir()
    conf_path = os.path.join(f,"doc","config.json")
    return load_json(conf_path)

def get_sch_config():
    f = load_json(path_dir)
    return f["schedule_details"]
   
def get_mail_config():
    f = load_json(path_dir)
    return f["mail_data"]




new_keywords = [
    "Petition",
    "Litigation",
    "Decree",
    "Appeal",
    "Default",
    "Allegation",
    "Fraud",
    "Cyber fraud",
    "Money Laundering",
    "Unauthorised",
    "Irregularity",
    "Voluntary Action Indicated",
    "Establishment Inspection Report",
    "Form 483 observation",
    "cGMP compliance",
    "Recall",
    "Cyber security",
    "RPT",
    "Related Party Transaction",
    "Non-Compliance",
    "Fine",
    "Misrepresentation",
    "Unfair trade",
    "Guilty",
    "Show-cause",
    "Writ petition",
    "Scandal",
    "Lawsuit",
    "Legal Proceeding",
    "Anti-Competitive Pricing",
    "Cartel",
    "Insider Trading",
    "Espionage",
    "Dispute",
    "Lobbying",
    "Whistleblower",
    "Arbitration",
    "FIR",
    "Settlement",
    "Child Labour",
    "Human Rights Violation",
    "Fire",
    "Accident",
    "Data Leakages",
    "Fatalities",
    "Community Rehabilitation",
    "Labour Right",
    "Strikes",
    "Misleading Advertisement",
    "Consumer Protection",
    "Consumer Awareness",
    "Boycotts",
    "Harassment",
    "Discrimination",
    "Cyber-attack",
    "Misleading",
    "Oil Spill",
    "Toxic emission",
    "Hazardous waste",
    "Rehabilitation",
    "Resettlement",
    "Water stress",
    "Contamination",
    "Deforestation",
    "Resource Depletion",
    "Environmental Fines",
    "Violation",
    "Penalty",
]

agency_keywords = [
    "RBI",
    "Reserve Bank of India",
    "Appellate Tribunal",
    "Securities Appellate Tribunal",
    "SEBI",
    "Securities and Exchange Board of India",
    "ED",
    "Enforcement Directorate",
    "Directorate of Enforcement",
    "Directorate General of Civil Aviation",
    "IRDAI",
    "Insurance Regulatory and Development Authority of India",
    "PFRDA",
    "Pension Fund Regulatory and Development Authority",
    "IBBI",
    "Insolvency and Bankruptcy Board of India",
    "NABARD",
    "National Bank for Agriculture and Rural Development",
    "SIDBI",
    "Small Industries Development Bank of India",
    "NHB",
    "National Housing Bank",
    "FSDC",
    "Financial Stability and Development Council",
    "AMFI",
    "Association of Mutual Funds in India",
    "MCA",
    "Ministry of Corporate Affairs",
    "Registrar of Companies",
    "Company Registration and Compliance",
    "TRAI",
    "Telecom Regulatory Authority of India",
    "CBFC",
    "Central Board of Film Certification",
    "FSSAI",
    "Food Safety and Standards Authority of India",
    "BIS",
    "Bureau of Indian Standards",
    "ASCI",
    "Advertising Standards Council of India",
    "CDSCO",
    "Central Drugs Standard Control Organisation",
    "CERC",
    "Central Electricity Regulatory Commission",
    "CCI",
    "Competition Commission of India",
    "WDRA",
    "Atomic Energy Regulatory Board",
    "Warehousing Development and Regulatory Authority",
    "EPFO",
    "Employees' Provident Fund Organisation",
    "DGMS",
    "Directorate General of Mines Safety",
    "ICA",
    "Institute of Chartered Accountants",
    "ICMAI",
    "Cost Accountants of India",
    "NASSCOM",
    "National Association of Software and Service Companies",
    "MAIT",
    "Manufacturers’ Association for Information Technology",
    "Indian Chemical Council",
    "INSA",
    "Indian National Shipowners’ Association",
    "PEPC",
    "Project Exports Promotion Council of India",
    "EEPC",
    "Engineering Export Promotion Council",
    "CBI",
    "Central Bureau of Investigation"
]

KEYWORDS_TO_CHECK = new_keywords + agency_keywords

# LEGACY KEYWORDS

# governance_keywords = [
#     "Fines", "Fraud", "Scandals", "Lawsuit", "Legal Proceedings", "Show Cause Notices",
#     "Anti-Competitive Pricing", "Cartel Formation", "FDA Investigation",
#     "Board Of Directors Resignation", "Bribery & Fraud", "Unfair Trade Practices",
#     "Insider Trading", "Corporate Espionage", "Shareholders Disputes",
#     "Lobbying", "whistleblower", "FIR", "Violation", "Penalty", "Settlement", "Cyber attack", "Misleading", "Arbitration"
# ]

# social_keywords = [
#     "Child Labour", "Human Rights Violation", "Fire", "Accident", "Fatalities",
#     "Data Leakages", "Community Rehabilitation", "Labour Rights", "Strikes",
#     "Misleading Advertisements", "Consumer Protection", "Consumer Awareness",
#     "consumer boycotts", "Child Labor", "Workplace Harassment", "Discrimination"
# ]

# environmental_keywords = [
#     "Oil Spills", "Toxic Emissions", "Hazardous Waste Disposal",
#     "Rehabilitation And Resettlement", "Water Stress", "Water Contamination",
#     "Deforestation", "Resource Depletion", "Environmental Fines"
# ]

# other_keywords = [
#     "US FDA","United States Food and Drug Administration","Money Laundering",
#     "Prevention of Money Laundering Act","Cyber Fraud","Directorate General of Civil Aviation",
#     "Form-483","Recall","Class 1","Class 2","Class 3","Arrest","Summoned",
#     "Fatality","Death","Injured"
# ]

#KEYWORDS_TO_CHECK = governance_keywords + social_keywords + environmental_keywords + other_keywords