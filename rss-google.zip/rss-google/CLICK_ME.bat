@echo off

title Google RSSFeed NewFetch
REM Change to the directory where your project and virtual environment are located
cd C:\Users\kaustubh.keny\Projects\OFFICE PROJECTS\goolge-rss-nse

REM Activate the virtual environment
@REM call .venv\Scripts\activate.bat

REM Run your Python script
python main.py

pause